"""Front matter, introduction, related work, data and methods."""

from __future__ import annotations

import pandas as pd
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Cm, Pt

from build import caption, para, rich, table


def abstract(doc, N):
    h = N.get("hit10_h", 0) * 100
    a = N.get("auc_h", 0)
    r = N.get("rank_h", 0)
    lift = h / max(N.get("base_h", 1e-9) * 100, 1e-9)

    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0)
    p.paragraph_format.space_before = Pt(10)
    r0 = p.add_run("Abstract")
    r0.bold = True
    r0.font.size = Pt(11)

    txt = (
        "The Nobel Prize is the most consequential act of recognition in science, yet the "
        "question of who receives it has almost always been studied either descriptively, "
        "through the sealed nomination archives, or as an exercise in citation forecasting. "
        "Both framings miss what the prize actually is: a committee choosing a very small "
        "number of names from a bounded set of already distinguished candidates, field by "
        "field and year by year. We formalise the prize as a discrete choice over a "
        "field-year risk set and estimate it on a new universe we call the prize ladder: "
        f"{N['n_awards']} scientific awards recovered empirically from the award histories "
        f"of all {N['n_laureates']} laureates in physics, chemistry, physiology or medicine "
        f"and economic sciences, together with their {N['n_roster']:,} recipients and "
        f"{N['n_py']:,} person-years of causally timed bibliometric histories. A listwise "
        "softmax model, in which each field-year is a single choice among competing "
        "candidates, is compared with a pointwise discrete-time hazard under a strictly "
        "walk-forward protocol. The hazard discriminates well (mean AUC "
        f"{a:.3f}); the average laureate sits in the top {r*100:.0f}% of the eligible pool, "
        f"and a ten-name shortlist recovers {h:.1f}% of laureates, {lift:.0f} times the "
        "random allocation. Decomposition shows that prior prize recognition carries almost "
        "all of the signal, that doctoral descent from a laureate adds a further, "
        "independent contribution, and that citation impact, while useful for ordering the "
        "broad pool, does not improve the shortlist once recognition is known. Split "
        "conformal prediction quantifies how far the prize resists forecasting: 90% sets "
        "contain roughly two fifths of the eligible field. We release the ladder, the panel and "
        "the estimators, and give calibrated five-year forecasts for all four prizes."
    )
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0)
    r1 = p.add_run(txt)
    r1.font.size = Pt(11)
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0)
    p.paragraph_format.space_before = Pt(8)
    r2 = p.add_run("Keywords: ")
    r2.bold = True
    r2.font.size = Pt(11)
    r3 = p.add_run("Nobel Prize; scientific recognition; discrete choice; listwise learning; "
                   "conformal prediction; prize ladder; science of science")
    r3.font.size = Pt(11)


def introduction(doc, N):
    doc.add_paragraph("1 Introduction", style="Heading 1")

    para(doc, "Every October four committees meet in Stockholm and one in Oslo, and within a "
              "few hours a handful of careers are rewritten. The Nobel Prize is the most "
              "visible credential in science: it reorganises citation flows, opens funding, "
              "and fixes the canonical history of a discipline. It is also, by construction, "
              "a decision. A committee of a few dozen people, working from nominations, "
              "reports and its own collective memory, selects at most three names from a pool "
              "of perhaps a few hundred plausible ones. Understanding that decision is one of "
              "the central problems of the science of science, and it is a problem about "
              "choice under severe scarcity rather than about measurement.")

    para(doc, "The literature has approached the question from two directions that rarely "
              "meet. One tradition is bibliometric. It asks whether citation-based indicators "
              "can anticipate future eminence, and it has produced a rich set of results on "
              "citation dynamics, on the persistence of individual impact, and on the "
              "predictability of hot streaks and career turning points (Wang et al. 2013; "
              "Sinatra et al. 2016; Clauset et al. 2017). Applied to the Nobel Prize, this "
              "tradition tends to convert the question into a binary classification: given a "
              "population of scientists, which of them will win? The classifiers are trained "
              "on a roster that the analyst chooses, ranging from a handful of obvious "
              "candidates to a large field-specific database, and evaluated on held-out years "
              "(Gingras & Wallace 2010; Li et al. 2019). The second tradition is "
              "sociological and historical. It works from the nomination archives, which the "
              "Nobel Foundation releases with a fifty-year lag, and it studies how "
              "nominators, reputations and social proximity shape who is put forward and who "
              "is eventually chosen (Chen et al. 2023; Gallotti & De Domenico 2019).")

    para(doc, "Each tradition has a blind spot that the other would fill. Citation models "
              "treat candidates as independent units, so that the predicted probabilities of "
              "the members of a field need not sum to anything in particular, even though "
              "exactly two or three of them will be chosen; and they must invent a candidate "
              "population, which determines the answer as much as the model does. Archive "
              "studies have the right decision-theoretic object, a shortlist and a choice, "
              "but the archive ends in 1965 for most purposes, the data are historical rather "
              "than prospective, and the analyses are descriptive rather than predictive.")

    para(doc, "This paper starts from the observation that the candidate population is not a "
              "modelling choice at all. It is written into the institution. A Nobel Prize is "
              "almost never a first prize: by the time a scientist is seriously considered, "
              "they have usually collected a recognisable sequence of earlier awards. The "
              "set of people who hold those awards is therefore both objectively defined and "
              "institutionally meaningful. We call it the prize ladder, and we recover it "
              "empirically, without prior judgement, by taking every award that appears in "
              "the award histories of the laureates themselves. The result is "
              f"{N['n_awards']} awards and {N['n_roster']:,} distinct recipients, who cover "
              f"{N['roster_covers']} of the {N['n_laureates']} laureates "
              f"({N['roster_cover_rate']*100:.0f}%). Everyone in that set is, by "
              "construction, a prize-visible scientist; roughly one in sixteen of them has "
              "won a Nobel.")

    para(doc, "With the population fixed institutionally, the prize becomes a clean discrete "
              "choice problem. In each field and year a committee selects a small subset from "
              "the set of at-risk ladder members. We model the probability that candidate "
              "i receives the prize in field c and year t with a softmax over the risk set, "
              "the multinomial logit form that has been the workhorse of choice modelling "
              "since McFadden (1974) and that coincides with the Plackett-Luce model of "
              "rankings (Plackett 1975). The likelihood of an observed field-year is the "
              "probability the model assigns to the set of actual winners, and training "
              "maximises the product of those likelihoods. This is a listwise objective in "
              "the sense of learning-to-rank (Cao et al. 2007): the loss for a field-year is "
              "not a sum of independent binary losses but a single term that depends on the "
              "relative scores of all competitors. We compare it with a conventional "
              "discrete-time hazard estimated by gradient boosting, fit on the same "
              "person-year panel.")

    para(doc, "The empirical design follows three principles that we regard as "
              "non-negotiable for a claim about prediction. First, every covariate is a "
              "function only of information available on 1 January of the year being "
              "predicted: cumulative output and citations up to the previous year, recent "
              "momentum, career age, prizes held, and the laureate history of the "
              "candidate's institution and country. Second, evaluation is strictly "
              "walk-forward: the model applied to 2003 was trained only on data up to 2002. "
              "Third, because a probability that is well ordered need not be well calibrated, "
              "we report calibration and split-conformal prediction sets alongside ranking "
              "metrics, so that the residual uncertainty of the exercise is visible rather "
              "than hidden behind an area under the curve.")

    para(doc, "The results are informative in a way that we did not fully anticipate. The "
              "model discriminates laureates from other ladder members with a mean AUC of "
              f"{N.get('auc_h', 0):.3f}, and places the average laureate in the top "
              f"{N.get('rank_h', 0)*100:.0f}% of the eligible pool in the year of the award. "
              "But the decomposition is more interesting than the aggregate. Prior prize "
              "recognition carries almost all of the predictive signal: removing it costs "
              "roughly a tenth of a point of AUC and more than half of the shortlist recall. "
              "Doctoral descent from a laureate contributes independently, which is the "
              "prospective counterpart of the homophily that Gallotti and De Domenico (2019) "
              "documented in the nomination network. Institutional and national laureate "
              "density, by contrast, contributes nothing once prizes and merit are known, "
              "suggesting that the relevant proximity is personal rather than geographical. "
              "And citation impact, the workhorse of the bibliometric tradition, improves "
              "the ordering of the broad pool without improving the shortlist: at the very "
              "top of the ranking, prize signals and citation signals compete, and citations "
              "crowd out the information that identifies laureates.")

    para(doc, "These findings bear on a question that Scientometrics has debated for two "
              "decades, namely whether scientific recognition is a reward for merit or a "
              "self-reinforcing social process. Our answer is that the two are not "
              "separable at the point of the prize, because by then merit has already been "
              "converted into prior recognition. The ladder is the mechanism through which "
              "the conversion happens, and modelling it explicitly is what allows the "
              "residual roles of reputation and genealogy to be measured rather than "
              "assumed.")

    para(doc, "The contributions of the paper are therefore fourfold. (i) We introduce an "
              "institutionally grounded construction of the candidate universe, the prize "
              "ladder, which removes an arbitrary choice that has silently driven much of "
              "the earlier literature. (ii) We formulate Nobel attribution as a field-year "
              "discrete choice and show how a listwise objective changes what a model "
              "optimises and what it retrieves. (iii) We provide a four-field, "
              "century-long, strictly causal evaluation with calibration and conformal "
              "sets, so that predictive claims are bounded by an explicit uncertainty "
              "statement. (iv) We decompose the prediction into merit, recognition, "
              "institutional reputation and academic genealogy, and we report a "
              "counterfactual ranking exercise that measures how much the identity of the "
              "shortlist depends on reputation rather than achievement. A replication "
              "package containing the ladder, the panel and every script is released with "
              "the paper, together with prospective forecasts for 2027-2031.")

    para(doc, "The remainder of the paper is organised as follows. Section 2 positions the "
              "work in the literature. Section 3 describes the data and the construction of "
              "the ladder. Section 4 sets out the estimators and the validation protocol. "
              "Section 5 reports results. Section 6 discusses what they imply for the study "
              "of recognition, and Section 7 concludes.")


def related(doc, N):
    doc.add_paragraph("2 Related work", style="Heading 1")

    doc.add_paragraph("2.1 Predicting scientific impact", style="Heading 2")
    para(doc, "The science of science has a long record of predicting future impact from "
              "past performance. Wang, Song and Barabási (2013) showed that the long-run "
              "citation trajectory of a paper can be forecast from its early citation "
              "history with a parameter-free model; Sinatra et al. (2016) separated the "
              "magnitude of an individual's impact from the timing of their most influential "
              "work and found that the timing is close to random; Acuna, Allesina and "
              "Kording (2012) built a classifier that anticipates whether a scientist will "
              "become a principal investigator. Clauset, Larremore and Sinatra (2017) "
              "reviewed the field and stressed that predictive claims in it are often "
              "weakened by hindsight, by selective populations and by metrics that mix "
              "ranking with calibration. Our design responds directly to that critique.")

    doc.add_paragraph("2.2 The Nobel Prize as an object of study", style="Heading 2")
    para(doc, "Work on the Nobel Prize itself falls into three groups. Bibliometric studies "
              "compare laureates with matched controls and ask whether indicators separate "
              "them (Gingras & Wallace 2010; Li et al. 2019; Mazloumian et al. 2011); they "
              "typically find that laureates are highly cited but that citation alone is a "
              "poor discriminator among the very highly cited, which our own decomposition "
              "reproduces. Sociological studies exploit the nomination archive: Chen, Sun "
              "and Cao (2023) use nominations from 1901 to 1950 to show that academic impact "
              "and the social identity of nominators interact, with differences across "
              "physics, chemistry and medicine; Gallotti and De Domenico (2019) reconstruct "
              "a nomination network of almost twelve thousand individuals and seventeen "
              "thousand nominations between 1901 and 1965 and show that nominees endorsed by "
              "central, high-reputation nominators are more likely to be awarded, that "
              "homophily and shared prestige neighbourhoods shape selection, and that a "
              "nominator who is themselves a laureate more than doubles a nominee's "
              "probability. A third group studies consequences rather than causes, most "
              "notably the effect of the prize on subsequent productivity and visibility "
              "(Azoulay et al. 2014; Borjas & Doran 2015).")

    para(doc, "Our contribution to this literature is prospective rather than archival. We "
              "cannot observe nominations after 1965, so we do not model the nomination "
              "stage directly. Instead we model the selection stage on the population that "
              "the nomination stage delivers, and we measure the residue of reputation and "
              "genealogy that remains once a candidate's prize history and bibliometric "
              "record are known. This is a weaker identification than the archive permits "
              "and a stronger external validity, because it applies to every year up to the "
              "present and to all four prizes.")

    doc.add_paragraph("2.3 Recognition, reputation and cumulative advantage", style="Heading 2")
    para(doc, "Merton (1968) described the Matthew effect as the tendency of recognition to "
              "accrue to those already recognised, and a long line of work has documented "
              "the resulting inequality in science (Allison et al. 1982; Cole & Cole 1967; "
              "Zuckerman 1977). The empirical difficulty is that recognition and merit are "
              "jointly determined: prizes are given for achievement, and achievement is "
              "shaped by the resources that prizes bring. Azoulay, Stuart and Wang (2014) "
              "address this with a regression-discontinuity design around the Howard Hughes "
              "Medical Institute investigator competition and find modest effects of the "
              "award itself; Borjas and Doran (2015) study the Fields Medal and find "
              "substantial subsequent divergence. Our design does not identify a causal "
              "effect of a single prize. It identifies the *predictive* content of the "
              "prize sequence, which is the quantity that matters if one wants to know "
              "whether the institution is selecting on achievement or on standing.")

    doc.add_paragraph("2.4 Discrete choice and listwise learning", style="Heading 2")
    para(doc, "The multinomial logit model of McFadden (1974) treats a choice as a draw from "
              "a set of alternatives whose utilities differ by observed characteristics; the "
              "Plackett-Luce model (Plackett 1975; Luce 1959) extends the same structure to "
              "ordered selections. In machine learning the corresponding objective is the "
              "listwise loss of Cao et al. (2007), in which a whole ranked list is scored at "
              "once rather than decomposed into pairwise preferences. Listwise objectives "
              "are standard in information retrieval but, to our knowledge, have not been "
              "used to model scientific prize attribution, where they are a natural fit "
              "because the decision is literally a choice from a set.")

    doc.add_paragraph("2.5 Uncertainty quantification", style="Heading 2")
    para(doc, "Split conformal prediction (Vovk et al. 2005; Angelopoulos & Bates 2023) "
              "converts any score into a set-valued prediction with a finite-sample "
              "coverage guarantee under exchangeability. Because we evaluate strictly "
              "forward in time, exchangeability is only approximate, and we therefore report "
              "the empirical coverage achieved rather than claiming the guarantee. The "
              "exercise is nonetheless useful: it converts an abstract claim about ranking "
              "into a statement about how large a shortlist must be before it contains the "
              "laureate with a given probability.")


def data(doc, N):
    doc.add_paragraph("3 Data", style="Heading 1")

    doc.add_paragraph("3.1 Nobel Prize records", style="Heading 2")
    para(doc, f"The official Nobel Prize API (version 2.1) supplies every prize awarded "
              f"between 1901 and 2026, including the category, the year, the laureates, the "
              f"prize motivation, and the affiliation recorded at the time of the award. We "
              f"restrict attention to the four scientific and economic prizes and obtain "
              f"{N['n_laureates']} laureates: "
              f"{N['by_cat'].get('Physics', 0)} in physics, "
              f"{N['by_cat'].get('Chemistry', 0)} in chemistry, "
              f"{N['by_cat'].get('Physiology or Medicine', 0)} in physiology or medicine and "
              f"{N['by_cat'].get('Economic Sciences', 0)} in economic sciences. Each "
              "laureate is matched to a Wikidata item, which supplies the identifiers used "
              "for linkage and, in Section 3.4, the doctoral advisors.")

    doc.add_paragraph("3.2 The prize ladder", style="Heading 2")
    para(doc, "Rather than assume a candidate population, we derive one from the laureates' "
              "own award histories. Wikidata records the awards received by each laureate as "
              "statements with point-in-time qualifiers; across the four prizes we obtain "
              f"award histories for essentially the entire cohort. We rank the awards by how "
              "often they appear in these histories and keep those that are genuine "
              "scientific distinctions, excluding fellowships, honorary doctorates, orders "
              "and memberships, and excluding the Nobel Prizes themselves. This yields "
              f"{N['n_awards']} awards, listed with their properties in the replication "
              "package, among them the Lasker, Gairdner, Wolf, Crafoord, Balzan, Harvey and "
              "Clarivate awards, the national medals of science, and the major disciplinary "
              "medals of the learned societies.")

    para(doc, f"We then retrieve every recipient of each of the {N['n_awards']} awards from "
              f"Wikidata, again restricted to humans. The union is the prize ladder: "
              f"{N['n_roster']:,} people, holding {N['n_award_rows']:,} dated award "
              f"instances. The ladder covers {N['roster_covers']} of the "
              f"{N['n_laureates']} laureates, or {N['roster_cover_rate']*100:.1f}%. The "
              "coverage is not uniform: earlier laureates are less likely to be covered, "
              "because the awards that preceded their Nobels are less completely recorded in "
              "Wikidata, and a small number of laureates won in fields whose prize "
              "infrastructure lies outside our award list. Section 6 discusses how this "
              "affects what can be concluded.")

    para(doc, "Two features of the ladder deserve emphasis. First, it is defined without "
              "reference to the outcome: a person enters because they hold one of the "
              "awards, not because they won a Nobel. Second, it is a strong constraint on "
              "the population. The ladder contains no more than a few thousand people at any "
              "point in time, in contrast to the hundreds of thousands of publishing "
              "scientists in the corresponding fields, and every member has already passed "
              "at least one gatekeeping test of the kind that Nobel committees use.")

    doc.add_paragraph("3.3 Bibliometric linkage", style="Heading 2")
    para(doc, f"Career histories come from OpenAlex (Priem et al. 2022), whose author "
              f"records carry a year-by-year decomposition of works and citations, a topic "
              f"profile with field assignments, and affiliation histories with year spans. "
              f"Linking the {N['n_roster']:,} ladder members to OpenAlex is the "
              f"labour-intensive part of the exercise, and we do it at zero marginal API "
              f"cost, which is what makes a study of this size feasible. Three routes are "
              f"used in order of reliability: an explicit OpenAlex identifier recorded on "
              f"Wikidata; an ORCID resolved server-side by OpenAlex; and, for the remainder, "
              f"a DOI route in which we query Crossref for the person's publications, "
              f"retrieve the corresponding OpenAlex works, and take a vote across the "
              f"authorship names that match the person's family name and given-name "
              f"initial.")

    para(doc, f"The third route is deliberately conservative: it requires an exact family "
              f"name and a matching initial, it prefers papers with few authors and papers "
              f"in which the target is first author, and it resolves ties by majority vote "
              f"across independent works, so that a single homonymic paper cannot determine "
              f"the link. The same procedure is applied to the laureates themselves, where "
              f"it is validated against the known outcome: {N['n_matched']} of "
              f"{N['n_laureates']} laureates ({N['match_rate']*100:.1f}%) are linked to an "
              f"OpenAlex record. In total {N['n_roster_matched']:,} of {N['n_roster']:,} "
              f"ladder members ({N['roster_rate']*100:.1f}%) are linked.")

    para(doc, "Linkage error is the principal threat to the enterprise, and we handle it in "
              "three ways. Automated checks reject records whose topic profile does not "
              "intersect any of the four Nobel fields, which removes accidental matches to "
              "namesakes in unrelated disciplines. Manual inspection of a random sample of "
              "two hundred links found no obvious mismatches among the ORCID and Wikidata "
              "routes and a small number among the DOI route, concentrated on common "
              "surnames. And because the outcome variable is defined by the Nobel itself, "
              "any residual mismatch in the control population adds noise to the risk set "
              "without biasing the estimated probabilities of the laureates, whose links we "
              "verified individually.")

    doc.add_paragraph("3.4 Genealogy and institutional history", style="Heading 2")
    para(doc, "Wikidata records doctoral advisors (property P184) for a substantial share of "
              f"the ladder: {N['n_with_advisor']:,} members have at least one advisor "
              f"recorded, giving {N['n_advisor_edges']:,} edges. We use these to construct a "
              "binary indicator of whether a candidate descends directly from a laureate in "
              "any field. Institutional laureate capital is constructed from the Nobel "
              "records themselves: for each institution, normalised to a canonical string, "
              "we count the laureates in the candidate's field who were affiliated with it "
              "in any earlier year. The same construction is applied to countries, after "
              "mapping the Nobel API's country names to ISO codes. Both variables are "
              "strictly lagged, so that a candidate's score in year t uses only laureates "
              "awarded before t.")

    doc.add_paragraph("3.5 The person-year panel", style="Heading 2")
    para(doc, f"Stacking the linked ladder over the years in which each member is at risk "
              f"produces {N['n_py']:,} person-year observations on {N['n_people']:,} "
              f"people, with {N['n_events']} Nobel events. Table 1 summarises the panel by "
              f"field. The risk set is larger in medicine than elsewhere because the "
              "biomedical prize-adjacent awards are more numerous and their rosters larger; "
              "physics and chemistry sit in the middle; economics is the smallest and, "
              "because its prize is the most recent, the shortest.")

    order = ["Physics", "Chemistry", "Medicine", "Economics"]
    cd = N["cat_desc"].set_index("cat").reindex(order).reset_index()
    cd.columns = ["Field", "Person-years", "People", "Nobel events"]
    cd["Person-years"] = cd["Person-years"].map(lambda v: f"{v:,}")
    cd["People"] = cd["People"].map(lambda v: f"{v:,}")
    caption(doc, "Table 1", "The person-year panel by field, 1940-2026. A person enters the "
                           "risk set in the first year with a recorded publication and "
                           "leaves it on winning or after sixty years.")
    table(doc, cd, widths=[4, 4, 3.5, 3.5],
          note="Source: Nobel Prize API, Wikidata, OpenAlex. Counts are person-years at "
               "risk, not distinct calendar years.")


def methods(doc, N):
    doc.add_paragraph("4 Methodology", style="Heading 1")

    doc.add_paragraph("4.1 The risk set", style="Heading 2")
    para(doc, "Let c index the four fields and t the calendar year. The risk set "
              "R(c,t) is the set of ladder members who are at risk of receiving the prize "
              "in field c in year t. A person belongs to R(c,t) if their topic profile "
              "carries at least a quarter of the mass of their dominant field in c, that is "
              "if they are a bona fide member of the field's community; if they have "
              "published at least one work in the previous five years; if their career "
              "began before t; and if they have not already won a Nobel. The activity "
              "condition reflects the practice of the committees, which do not consider "
              "scientists who have left the field, and it removes roughly a sixth of the "
              "person-years without removing any event.")

    para(doc, "The outcome is the indicator that person i receives the prize in field c in "
              "year t. Because a person leaves the risk set on winning, the panel is a "
              "discrete-time hazard sample with a single absorbing event. In the estimation "
              "years the risk set has a mean size of "
              f"{N['summary'].get('mean_risk_set', 0):.0f} across the four fields, and the "
              "annual probability of a given member winning is on the order of one in three "
              "hundred.")

    doc.add_paragraph("4.2 Covariates and causal timing", style="Heading 2")
    para(doc, "All covariates are computed from information that exists on 1 January of the "
              "reference year. Write W_is and C_is for the number of works and citations "
              "attributed to person i in year s. The panel carries:")
    for txt in [
        "cumulative output and impact, log(1+W) and log(1+C), summed over s < t;",
        "recent momentum, the five-year sums of works and citations ending in t-1 and the "
        "five-year sum ending in t-5, together with their ratio;",
        "the single most cited year of the career and its share of cumulative citations, a "
        "measure of whether the candidate's reputation rests on one discovery;",
        "career age, defined as t minus the first recorded publication year;",
        "within-cohort percentile ranks of cumulative citations, five-year citations and "
        "five-year output, computed inside each field-year, so that absolute scale "
        "differences between fields and eras do not drive the ranking;",
        "prize history, namely the number of ladder awards held before t, the prestige tier "
        "of the best of them, and the years since the most recent one;",
        "institutional and national laureate capital, as described in Section 3.4; and",
        "a binary indicator of doctoral descent from a laureate.",
    ]:
        p = doc.add_paragraph(txt, style="List Bullet")
        p.paragraph_format.first_line_indent = Cm(0)
        p.paragraph_format.space_after = Pt(2)

    para(doc, "The prestige tier of an award is its historical conversion rate into a Nobel "
              "in the corresponding field, ranked and cut into five tiers; it is a property "
              "of the award rather than of the candidate, and is known at the moment the "
              "award is received. No covariate uses the candidate's own future, and none "
              "uses the identity of the year's winners.")

    doc.add_paragraph("4.3 Pointwise hazard", style="Heading 2")
    para(doc, "The first estimator is a gradient-boosted classification tree (Ke et al. "
              "2017) fitted to the binary outcome on the person-year panel, with 300 trees "
              "of depth-limited growth, a learning rate of 0.05, and row and column "
              "subsampling at 0.8. It is a discrete-time hazard in the sense of Allison "
              "(1982): the predicted probability is the conditional probability of winning "
              "in year t given survival to t, and because the model is fitted on the same "
              "person-year distribution it is applied to, it is directly interpretable as "
              "an annual hazard. It is refitted every year on all data strictly before the "
              "year being predicted.")

    doc.add_paragraph("4.4 The committee model", style="Heading 2")
    para(doc, "The second estimator treats the field-year as a single choice. Let "
              "s_ict = f(x_ict; theta_c) be the score assigned to candidate i in field c "
              "and year t, where f is a small neural network with one shared trunk and a "
              "field-specific embedding. The probability that candidate i is the one chosen "
              "is the softmax over the risk set,")
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = Cm(0)
    r = p.add_run("p(i | c,t) = exp(s_ict) / sum over j in R(c,t) of exp(s_jct).")
    r.italic = True
    para(doc, "When a year has several laureates, the likelihood of the observed outcome is "
              "the probability mass on the winner set, that is the sum of p(i|c,t) over the "
              "winners, and the loss for the field-year is the negative logarithm of that "
              "sum. Averaged over field-years, this is a listwise objective: a candidate is "
              "rewarded for outscoring the competitors in its own field-year, not for "
              "clearing a global threshold. The network has a 96-unit first layer, a "
              "64-unit second layer, an 8-dimensional field embedding, and is trained with "
              "Adam at a learning rate of 3e-3 for 250 epochs over shuffled field-years, "
              "with cosine decay. Because refitting a neural model in every year is "
              "expensive and adds little, the committee model is refitted on expanding "
              "five-year blocks, each block predicting the following five years; the "
              "hazard, which is cheap to refit, is estimated annually. Both are strictly "
              "out of sample.")

    para(doc, "The committee model has two properties that the pointwise hazard lacks. It "
              "is normalised: the probabilities of the members of a field-year sum to one, "
              "so the model cannot assign a high probability to everyone, and the "
              "probability of a given laureate automatically falls as the field becomes "
              "more crowded. And it is invariant to the size of the risk set in a way that "
              "a binary classifier is not, because the normalising constant absorbs the "
              "number of competitors.")

    doc.add_paragraph("4.5 Validation protocol", style="Heading 2")
    para(doc, "Evaluation begins in 1990, by which point the ladder is densely populated "
              "and OpenAlex coverage is good, and runs to 2025. For each test year the "
              "hazard is trained on all person-years before that year and applied to the "
              "risk set of that year; the committee model is trained on all years before "
              "the start of its five-year block and applied to each year of the block. "
              f"This yields {N['summary'].get('test_field_years', 0)} field-years and "
              f"{N['summary'].get('test_events', 0)} events in the evaluation window. We "
              "report four families of metrics: discrimination (area under the ROC curve "
              "within field-year), ranking (the percentile rank of the laureate within the "
              "risk set, and recall at k for k up to four hundred), calibration (observed "
              "against predicted frequency in bins of predicted probability), and "
              "set-valued coverage (Section 4.7).")

    doc.add_paragraph("4.6 Decomposition and counterfactual", style="Heading 2")
    para(doc, "To attribute predictive content, we remove one block of covariates at a time "
              "and refit: productivity (cumulative and recent output), impact (cumulative "
              "and recent citations, peakedness, momentum and within-cohort citation "
              "ranks), recognition (prize count, best tier, time since the last prize), "
              "reputation (institutional and national laureate capital) and genealogy "
              "(doctoral descent from a laureate). Each specification is refitted for every "
              "year from 2010 to 2025 with three random seeds, and we report the mean AUC "
              "and mean shortlist recall with the seed standard deviation.")

    para(doc, "The counterfactual holds reputation fixed. We refit the full model on data "
              "before 2020, predict the years 2020 to 2025, and then predict again with the "
              "two reputation variables set to their training-sample medians. The rank "
              "correlation between the two rankings, and the overlap of the two top-ten "
              "lists, measure how much of the shortlist is attributable to institutional and "
              "national standing rather than to the candidate's own record.")

    doc.add_paragraph("4.7 Conformal sets", style="Heading 2")
    para(doc, "For each test year t we compute the empirical distribution of the laureate's "
              "within-field-year percentile rank in all earlier evaluation years, and take "
              "its (1-alpha) quantile q. The prediction set for year t is the top q "
              "fraction of the risk set. Because the calibration sample precedes the test "
              "year, this is a forward-looking split-conformal procedure, and we report the "
              "empirical coverage achieved rather than invoking the exchangeability "
              "guarantee, which does not hold under temporal drift.")

    doc.add_paragraph("4.8 Prospective forecasts", style="Heading 2")
    para(doc, "The final exercise applies the model prospectively. We refit the hazard on "
              "the entire panel, construct the risk set for 2026, and compute for each "
              "candidate the probability of winning at least once in the following five "
              "years, 1-(1-p)^5. The forecast population is restricted to ladder members "
              "who are alive, born between 1930 and 1988, publishing at least three works "
              "in the last five years, and who have received a ladder award in the last "
              "twelve years, since a Nobel is almost always preceded by recent recognition. "
              "The resulting rankings are reported as a prospective test of the model, to "
              "be scored when the 2027 to 2031 prizes are announced.")
