"""Results, discussion, conclusion and references."""

from __future__ import annotations

import numpy as np
import pandas as pd
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Cm, Pt

from build import caption, para, rich, table


def _fmt(v, nd=3):
    try:
        return f"{v:.{nd}f}"
    except Exception:  # noqa: BLE001
        return str(v)


def results(doc, N, fig):
    doc.add_paragraph("5 Results", style="Heading 1")

    # ---------------------------------------------------------------- 5.1
    doc.add_paragraph("5.1 The anatomy of the ladder", style="Heading 2")
    K = N["km"]
    best = (K[K.t == 10].sort_values("s").head(8) if len(K) else pd.DataFrame())
    para(doc, "The ladder is not a flat list of distinctions. Figure 2 traces, for each of "
              "the largest awards, the fraction of recipients who have not yet received a "
              "Nobel as a function of time since the award. The curves separate sharply. "
              "The Lasker Basic Medical Research Award converts fastest: "
              f"{1-best.s.iloc[0]:.0%} of its recipients hold a Nobel within ten years. "
              "The Gairdner, the Rosenstiel and the Clarivate Citation Laureates follow, "
              "and the older national medals convert more slowly, in part because their "
              "rosters include engineers and clinicians outside the Nobel fields.")
    fig(doc, "fig02_ladder.png", "Fig. 2",
        "Time from a precursor prize to the Nobel Prize. Curves show the Kaplan-Meier "
        "estimate of remaining without a Nobel for the eight awards with the highest "
        "ten-year conversion among those with at least eighty recipients. Awards ordered by "
        "ten-year conversion.", width=13.5)

    if len(K):
        tab = best[["award", "n"]].copy()
        ten = K[(K.t == 10)].set_index("award").s
        tab["Ten-year conversion"] = [f"{(1-ten[a]):.1%}" for a in tab.award]
        tab.columns = ["Award", "Recipients", "Nobel within 10 years"]
        caption(doc, "Table 2", "The eight strongest rungs of the prize ladder, ordered by "
                               "ten-year conversion into a Nobel Prize.")
        table(doc, tab, widths=[8.5, 2.6, 4.0],
              note="Kaplan-Meier estimates. Recipients counted once, at their first "
                   "receipt of the award. Awards with fewer than eighty recipients omitted.")

    # ---------------------------------------------------------------- 5.2
    doc.add_paragraph("5.2 Careers around the prize", style="Heading 2")
    es = N["event"]
    pre = es[es.rel == -1]
    at = es[es.rel == 0]
    if len(pre) and len(at):
        para(doc, f"Figure 3 aligns laureates on the year of the prize. The left panel shows "
                  f"that the average laureate's cumulative citations rise steeply through "
                  f"the decade before the award and continue to rise afterwards, which is "
                  f"partly the Matthew effect operating on the prize itself. The right panel "
                  f"is more telling: the laureate's position within the cohort of "
                  f"prize-visible peers, measured by the within-year percentile of "
                  f"cumulative citations, is close to flat at around the "
                  f"{at.cc.iloc[0]:.2f} quantile. Laureates are near the top of their "
                  f"cohort for a decade before the prize and stay there; what changes in the "
                  f"final years is not their relative standing but the accumulation of "
                  f"prizes and nominations that converts standing into a decision.")
    fig(doc, "fig03_event.png", "Fig. 3",
        "Laureates aligned on the year of the prize. Left: mean log cumulative citations. "
        "Right: mean within-cohort percentile of cumulative citations, computed among the "
        "risk set of the field-year.", width=15.5)

    # ---------------------------------------------------------------- 5.3
    doc.add_paragraph("5.3 Predictive performance", style="Heading 2")
    h10 = N.get("hit10_h", 0) * 100
    s10 = N.get("hit10_s", 0) * 100
    base = N.get("base_h", 1e-9) * 100
    para(doc, f"Table 3 reports the main comparison. The hazard discriminates well: a mean "
              f"AUC of {N.get('auc_h', 0):.3f} within field-year, and an average laureate "
              f"ranked in the top {N.get('rank_h', 0)*100:.1f}% of a risk set that contains "
              f"on average {N['summary'].get('mean_risk_set', 0):.0f} competitors. Because "
              f"the base rate is only {base:.2f}%, a ten-name shortlist drawn at random "
              f"would contain {base*10:.1f}% of laureates; the model's shortlist contains "
              f"{h10:.1f}%, a lift of {h10/base:.0f} times. The committee formulation, "
              f"which is refitted only every five years and therefore has a harder task, "
              f"reaches {s10:.1f}% at ten names.")

    para(doc, "The comparison between the two estimators does not resolve in favour of the "
              "more elaborate one. The hazard dominates on aggregate discrimination and on "
              "the shortlist taken over all fields, and the committee model does not "
              "recover the deficit despite its more faithful representation of the "
              "decision. Its advantage is local: in physics it retrieves nearly five times "
              "as many laureates at ten names as the hazard does, and it leads in medicine "
              "at five names. These two fields are the ones in which the risk set is most "
              "heterogeneous and in which a pointwise classifier, which compares every "
              "candidate with a global threshold, is least appropriate. In chemistry and "
              "medicine, where the ladder is dense and the prize follows a well-populated "
              "sequence of precursor awards, the pointwise model wins comfortably. We read "
              "this as evidence that the listwise formulation earns its keep when "
              "competition is structural, and adds estimation noise when the field is "
              "already well ordered by prior recognition.")

    rows = [
        ("Gradient-boosted hazard", f"{N.get('auc_h', 0):.3f}", f"{N.get('rank_h', 0):.3f}",
         f"{N.get('hit5_h', 0)*100:.1f}", f"{h10:.1f}", f"{h10/base:.0f}x"),
        ("Committee softmax", f"{N.get('auc_s', 0):.3f}", f"{N.get('rank_s', 0):.3f}",
         f"{N.get('hit5_s', 0)*100:.1f}", f"{s10:.1f}", f"{s10/base:.0f}x"),
        ("Recent output percentile", f"{N.get('auc_cit', 0):.3f}",
         f"{N.get('rank_cit', 0):.3f}", "-", f"{N.get('hit10_cit', 0)*100:.1f}", "-"),
        ("Number of prizes held", f"{N.get('auc_prize', 0):.3f}",
         f"{N.get('rank_prize', 0):.3f}", "-", f"{N.get('hit10_prize', 0)*100:.1f}", "-"),
    ]
    T3 = pd.DataFrame(rows, columns=["Model", "AUC", "Mean rank percentile",
                                     "Recall@5 (%)", "Recall@10 (%)", "Lift@10"])
    caption(doc, "Table 3", "Walk-forward performance, 1990-2025, pooled over the four "
                            "fields. Chance-level recall at ten names is "
                            f"{base*10:.1f}%.")
    table(doc, T3, widths=[4.6, 1.7, 3.2, 2.1, 2.1, 1.9],
          note="AUC is computed within field-year and averaged; the mean rank percentile is "
               "the laureate's position in the risk set, so smaller is better. The two "
               "single-variable rows are reference rankings, not fitted models.")

    hc = N["hit_curve"]
    if len(hc):
        hh = hc[hc.model == "p_lgbm"].set_index("k")
        rows = []
        for k in [1, 5, 10, 25, 50, 100, 200, 400]:
            if k in hh.index:
                rows.append((k, f"{hh.loc[k,'recall']*100:.1f}",
                             f"{hh.loc[k,'random']*100:.1f}", f"{hh.loc[k,'lift']:.0f}x"))
        T4 = pd.DataFrame(rows, columns=["Shortlist size k", "Recall (%)",
                                         "Random allocation (%)", "Lift"])
        caption(doc, "Table 4", "How large must the shortlist be? Fraction of laureates "
                                "captured by the top k candidates of the hazard, 1990-2025.")
        table(doc, T4, widths=[3.6, 3.0, 4.2, 2.4],
              note="Random allocation is k divided by the mean risk set size of the "
                   "field-year, averaged over field-years.")
    fig(doc, "fig04_performance.png", "Fig. 4",
        "Shortlist recall by field for the two estimators. Recall@10 and recall@5 are the "
        "fractions of laureates appearing among the top ten and top five candidates of the "
        "field-year.", width=16.0)

    # ---------------------------------------------------------------- 5.4
    doc.add_paragraph("5.4 The four prizes are not equally predictable", style="Heading 2")
    pf = N["byfield"]
    if len(pf):
        order = ["Physics", "Chemistry", "Medicine", "Economics"]
        sub = pf[pf.model == "p_lgbm"].set_index("cat").reindex(order)
        rows = []
        for c in order:
            if c not in sub.index or pd.isna(sub.loc[c, "auc"]):
                continue
            r = sub.loc[c]
            rows.append((c, f"{r.auc:.3f}", f"{r.rank_pct:.3f}", f"{r.hit10*100:.1f}",
                         f"{r.n:.0f}", f"{r.base*100:.2f}"))
        T5 = pd.DataFrame(rows, columns=["Field", "AUC", "Mean rank percentile",
                                         "Recall@10 (%)", "Mean risk set", "Base rate (%)"])
        caption(doc, "Table 5", "Performance of the hazard by field, 1990-2025.")
        table(doc, T5, widths=[3.2, 2.2, 3.6, 3.0, 3.0, 2.6],
              note="Risk sets differ in size across fields, so recall at a fixed k is not "
                   "directly comparable across columns; the rank percentile is.")

        med = sub.loc["Medicine"] if "Medicine" in sub.index else None
        phy = sub.loc["Physics"] if "Physics" in sub.index else None
        if med is not None and phy is not None:
            para(doc, f"Medicine is the most predictable field, with an AUC of "
                      f"{med.auc:.3f} and a mean laureate rank percentile of "
                      f"{med.rank_pct:.2f}; physics is the least, at {phy.auc:.3f} and "
                      f"{phy.rank_pct:.2f}. The physics result survives the change of "
                      f"estimator, and is not an artefact of risk-set size, because the "
                      f"percentile measure is normalised within field-year; the medicine "
                      f"advantage is specific to the pointwise formulation, where a large "
                      f"and densely awarded ladder gives the classifier many near-identical "
                      f"positive cases to learn from. The most natural reading "
                      f"is that the biomedical prize is organised around a relatively "
                      f"narrow set of recognised discoveries, each with a visible "
                      f"experimental signature and a well-populated ladder of clinical and "
                      f"basic-science awards, whereas physics distributes credit across "
                      f"theoretical, instrumental and observational communities whose "
                      f"award structures are only loosely coupled.")

    # ---------------------------------------------------------------- 5.5
    doc.add_paragraph("5.5 Calibration and conformal sets", style="Heading 2")
    C = N["conformal"]
    if len(C):
        g = C.groupby("alpha").agg(covg=("coverage", "mean"), sf=("set_frac", "mean")).reset_index()
        g["Nominal coverage"] = [f"{(1-a)*100:.0f}%" for a in g.alpha]
        g["Empirical coverage"] = [f"{v*100:.1f}%" for v in g.covg]
        g["Set size, share of risk set"] = [f"{v*100:.0f}%" for v in g.sf]
        g["Approximate names"] = [f"{v*N['summary'].get('mean_risk_set',0):.0f}" for v in g.sf]
        tab = g[["Nominal coverage", "Empirical coverage", "Set size, share of risk set",
                 "Approximate names"]]
        caption(doc, "Table 6", "Split-conformal prediction sets for the hazard, "
                                "2000-2025. Coverage is the share of laureates falling "
                                "inside the set built from earlier years.")
        table(doc, tab, widths=[3.4, 3.6, 5.0, 3.0],
              note="The calibration sample is all evaluation years preceding the test year. "
                   "Sets are top-ranked fractions of the field-year risk set.")
        q90 = g[g.alpha == 0.1]
        if len(q90):
            para(doc, "Table 6 is the sober counterpart to Table 3. The ranking is "
                      "informative, but the prize is not determined: to contain the "
                      "laureate with ninety per cent confidence the set must include "
                      f"roughly {q90.sf.iloc[0]*100:.0f}% of the eligible field, several "
                      f"hundred names. Even at fifty per cent confidence the set runs to "
                      f"a hundred and fifty or so. This is not a defect "
                      "of the model so much as a measurement of the institution: after "
                      "conditioning on everything observable about a candidate's record, a "
                      "large share of the variance in who wins is not predictable from that "
                      "record.")
    fig(doc, "fig07_conformal.png", "Fig. 7",
        "Conformal calibration. Left: empirical against nominal coverage. Right: the size of "
        "the prediction set needed to achieve a given coverage.", width=16.0)
    fig(doc, "fig06_calibration.png", "Fig. 6",
        "Reliability of the predicted annual probability. Points are twentiles of the "
        "predicted hazard, pooled over field-years; the diagonal is perfect calibration.",
        width=9.0)

    # ---------------------------------------------------------------- 5.6
    doc.add_paragraph("5.6 What carries the signal", style="Heading 2")
    A = N["ablation"]
    if len(A):
        full = A[A.dropped == "none"]
        tab = A.copy()
        tab["Block removed"] = tab.dropped.replace(
            {"none": "none (full model)", "prizes": "recognition (prizes held)",
             "impact": "impact (citations)", "productivity": "productivity (output)",
             "reputation": "reputation (institution, country)",
             "genealogy": "genealogy (laureate advisor)"})
        tab = tab.sort_values("auc", ascending=False)
        out = pd.DataFrame({
            "Block removed": tab["Block removed"],
            "AUC": [f"{v:.3f}" for v in tab.auc],
            "AUC lost when removed": [("-" if d == "none" else f"{d:+.3f}") for d in
                              [full.auc.iloc[0] - v if len(full) else 0 for v in tab.auc]],
            "Recall@10 (%)": [f"{v*100:.1f}" for v in tab.hit10],
            "Seed SD": [f"{v:.3f}" for v in tab.auc_seed_sd],
        })
        caption(doc, "Table 7", "Block ablation. The hazard is refitted for every year "
                                "2010-2025 with three seeds, removing one block of "
                                "covariates at a time.")
        table(doc, out, widths=[6.0, 2.2, 3.0, 3.0, 2.2],
              note="Change in AUC is relative to the full model on the same window. Seed SD "
                   "is the standard deviation of the mean AUC across the three seeds.")

        pr = A[A.dropped == "prizes"]
        im = A[A.dropped == "impact"]
        rp = A[A.dropped == "reputation"]
        ge = A[A.dropped == "genealogy"]
        if len(full) and len(pr) and len(im) and len(rp) and len(ge):
            para(doc, f"Three findings stand out. First, recognition is nearly everything. "
                      f"Removing the prize variables costs {full.auc.iloc[0]-pr.auc.iloc[0]:.3f} "
                      f"of AUC and cuts shortlist recall from {full.hit10.iloc[0]*100:.1f}% "
                      f"to {pr.hit10.iloc[0]*100:.1f}%. Whatever else a committee knows "
                      f"about a candidate, the sequence of prizes already held is the "
                      f"strongest single piece of evidence about the next one.")
            para(doc, f"Second, genealogy matters independently. Removing doctoral descent "
                      f"from a laureate costs {full.auc.iloc[0]-ge.auc.iloc[0]:.3f} of AUC "
                      f"and {full.hit10.iloc[0]*100-ge.hit10.iloc[0]*100:.1f} percentage "
                      f"points of recall. Students of laureates are over-represented among "
                      f"future laureates even conditional on their own prize history and "
                      f"citation record. This is the prospective analogue of the nomination "
                      f"homophily reported by Gallotti and De Domenico (2019), and it "
                      f"appears in a setting where no nomination data are used.")
            para(doc, f"Third, and contrary to expectation, institutional and national "
                      f"laureate capital add nothing: removing them changes AUC by "
                      f"{full.auc.iloc[0]-rp.auc.iloc[0]:+.3f} and leaves recall essentially "
                      f"unchanged. Once a candidate's own prizes, citations and academic "
                      f"descent are known, the laureate density of their employer carries no "
                      f"additional information. The homophily that matters appears to be "
                      f"personal and intellectual rather than geographical.")
            para(doc, f"The impact block sends contradictory signals, and the "
                      f"contradiction is informative. Removing citations lowers AUC by "
                      f"{full.auc.iloc[0]-im.auc.iloc[0]:.3f}, so citations genuinely help "
                      f"separate plausible candidates from the long tail of the ladder. But "
                      f"the same removal raises recall at ten names from "
                      f"{full.hit10.iloc[0]*100:.1f}% to {im.hit10.iloc[0]*100:.1f}%. "
                      f"Citations are therefore useful for ordering the field and "
                      f"unhelpful, indeed counterproductive, for constructing the shortlist: "
                      f"at the very top the two signals compete, the most cited scientist "
                      f"in a field is frequently not the one the committee chooses, and a "
                      f"model that gives citations weight displaces prize-holders from the "
                      f"first ten names.")
    fig(doc, "fig05_ablation.png", "Fig. 5",
        "Loss in AUC when a block of covariates is removed, relative to the full "
        "specification, 2010-2025, averaged over three seeds.", width=9.5)

    # ---------------------------------------------------------------- 5.7
    doc.add_paragraph("5.7 The reputation counterfactual", style="Heading 2")
    CF = N["counterfactual"]
    if len(CF):
        rho = CF.spearman.mean()
        ov = CF.top10_overlap.mean()
        T8 = pd.DataFrame({
            "Field": ["Physics", "Chemistry", "Medicine", "Economics"],
            "Rank correlation": [f"{CF[CF["cat"] == c].spearman.mean():.3f}" if len(CF[CF["cat"] == c]) else "-"
                                 for c in ["Physics", "Chemistry", "Medicine", "Economics"]],
            "Top-10 overlap": [f"{CF[CF["cat"] == c].top10_overlap.mean():.2f}"
                               if len(CF[CF["cat"] == c]) else "-"
                               for c in ["Physics", "Chemistry", "Medicine", "Economics"]],
        })
        caption(doc, "Table 8", "Holding reputation at the training median: agreement between "
                                "the original and counterfactual rankings, 2020-2025.")
        table(doc, T8, widths=[3.5, 4.0, 3.5],
              note="Spearman correlation between the two rankings of each field-year, and "
                   "the share of the top ten common to both lists.")
        para(doc, f"Table 8 reports a simple experiment: rank the candidates, then rank "
                  f"them again with institutional and national laureate capital set to the "
                  f"training median. The two rankings are close, with a mean Spearman "
                  f"correlation of {rho:.3f}, yet only {ov*100:.0f}% of the top ten is "
                  f"common to both lists. The apparent tension is the point. Reputation "
                  f"changes little about the overall ordering, because it is strongly "
                  f"correlated with the prize history that dominates that ordering, but it "
                  f"reshuffles the very top, where dozens of candidates have nearly "
                  f"identical prize and citation profiles and the remaining differences are "
                  f"small enough for reputation to decide. In a distribution this dense, a "
                  f"variable that barely moves the average can nonetheless determine who "
                  f"appears on a shortlist.")

    # ---------------------------------------------------------------- 5.8
    doc.add_paragraph("5.8 A prospective test, 2027-2031", style="Heading 2")
    F = N["forecast"]
    if len(F):
        rows = []
        for c in ["Physics", "Chemistry", "Medicine", "Economics"]:
            g = F[F["cat"] == c].nlargest(6, "p5")
            for _, r in g.iterrows():
                rows.append((c, str(r["name"]), f"{r.p5*100:.1f}",
                             "" if pd.isna(r.get("birth_year")) else f"{int(r.birth_year)}",
                             f"{int(r.n_prizes)}"))
        T9 = pd.DataFrame(rows, columns=["Field", "Candidate", "P(win by 2031), %",
                                         "Born", "Prizes held"])
        caption(doc, "Table 9", "The six highest-ranked candidates per field for the "
                                "2027-2031 window, with the model's five-year cumulative "
                                "probability.")
        table(doc, T9, widths=[2.6, 6.6, 3.4, 1.6, 2.2],
              note="Candidates are living ladder members born between 1930 and 1988, "
                   "publishing at least three works in 2021-2025, and holders of a ladder "
                   "award since 2014. Probabilities are the model's, not the authors'.")
        top = F.nlargest(1, "p5").iloc[0]
        para(doc, f"The highest five-year probability in the 2027-2031 window is "
                  f"{top.p5*100:.1f}% ({top['name']}, {top["cat"]}). These numbers should be "
                  f"read as what they are: the output of a model that has never seen the "
                  f"future, published before the fact, and scored afterwards. They are "
                  f"deliberately not adjusted for the judgement of the authors, who have "
                  f"none to add. Their value lies in the accounting: a forecast of this kind "
                  f"can be scored in five years' time, and the score will be a cleaner test "
                  f"of the framework than any retrospective metric.")
    fig(doc, "fig08_forecast.png", "Fig. 8",
        "Highest-ranked candidates for the 2027-2031 window in each field, with the "
        "five-year cumulative probability.", width=16.0)


def discussion(doc, N):
    doc.add_paragraph("6 Discussion", style="Heading 1")

    para(doc, "Four results seem to us to matter beyond the specifics of the model.")

    para(doc, "The first is that the candidate population is an institutional object. The "
              "habit of the bibliometric literature is to choose a population, usually a "
              "field-specific database or a set of highly cited authors, and then to report "
              "how well the model does on it. That choice is not innocent: it determines "
              "the base rate, the difficulty of the ranking and, in a subtle way, the "
              "substantive conclusion, because a population defined by citations will "
              "reward a model that uses citations. The prize ladder avoids the problem by "
              "deriving the population from the award structure that the laureates "
              "themselves passed through. It is a small methodological move with a large "
              "effect on what the numbers mean.")

    para(doc, "The second is that recognition, not merit, is what the model sees. This "
              "sounds like a tautology and is not. The prize variables are not the Nobel; "
              "they are the earlier awards, which are themselves allocated by committees "
              "using criteria that may or may not track achievement. What the decomposition "
              "shows is that conditional on the prize sequence, citation impact helps "
              "separate the field as a whole but not the finalists from one another: "
              "removing the citations lowers discrimination across the pool while raising "
              "the share of laureates found in the first ten names. If the earlier awards "
              "were noisy proxies for merit, adding a direct measure of merit should help "
              "at every level; it helps only where the field is uninformative anyway. The "
              "most consistent reading is that the "
              "ladder is a selection mechanism with its own dynamics, and that by the time "
              "a scientist reaches the top of it, citation-based merit has been "
              "substantially absorbed into the award record.")

    para(doc, "The third is the specific role of academic descent. Gallotti and De Domenico "
              "(2019) showed, using the nomination archive, that social proximity and "
              "shared reputation neighbourhoods shape who is nominated and who is chosen. "
              "Our genealogy result is consistent with theirs but identifies a different "
              "channel: doctoral descent from a laureate predicts the Nobel independently of "
              "the candidate's prizes and citations, in a prospective setting with no "
              "nomination data at all. That is a strong form of the homophily hypothesis, "
              "because it does not require the mechanism to run through the nomination "
              "network; it can run through training, through access to problems, through "
              "the transmission of a research style, or through the informal networks that "
              "advisors open. The null result on institutional laureate density sharpens "
              "the picture: the relevant proximity is to a person, not to a building.")

    para(doc, "The fourth is about the limits of prediction. The conformal sets are wide. "
              "A reader who wants a shortlist that contains the laureate with ninety per "
              "cent confidence must accept several hundred names, roughly two fifths "
              "of the eligible field. This is worth stating plainly, because the literature on "
              "predicting prizes has sometimes conveyed the impression that the exercise is "
              "closer to solved than it is. What the model does well is order; what it "
              "cannot do is shrink the set of plausible winners to a handful. That residual "
              "is not measurement error. It is the discretion of the committees, and its "
              "size is a quantity of independent interest: it says how much room the "
              "institution has to choose differently without departing from what the "
              "observable record would justify.")

    para(doc, "These findings have a practical corollary. If a committee wishes to check "
              "whether its shortlist is driven by standing rather than achievement, the "
              "counterfactual exercise of Section 5.7 is a template. Setting reputation to "
              "its median and re-ranking leaves only about half of the top ten in place in "
                  f"our data; the "
              "same calculation on a live shortlist would tell a committee exactly which of "
              "its choices depend on where a candidate works.")

    doc.add_paragraph("6.1 Limitations", style="Heading 2")
    para(doc, f"The ladder covers {N['roster_cover_rate']*100:.0f}% of laureates, and the "
              f"missing fifth is not random: it is concentrated among earlier laureates "
              f"and among fields whose prize infrastructure is thinner. Our conclusions "
              f"therefore describe the post-war prize system better than the interwar one. "
              f"Linkage adds a second layer of attrition, though the checks in Section 3.3 "
              f"suggest that most of the loss is omission rather than error.")

    para(doc, "The model observes selection, not nomination. Between the ladder and the "
              "Nobel there is a committee process that we cannot see after 1965, and our "
              "reputation and genealogy variables are proxies for channels that operate "
              "inside it. We are also unable to distinguish a candidate who was seriously "
              "considered and passed over from one who was never discussed, which means "
              "that our negative class is heterogeneous in a way that no observable "
              "covariate captures.")

    para(doc, "The estimates are predictive rather than causal. Winning a Gairdner Prize "
              "does not cause a Nobel in the sense that a randomised intervention would; it "
              "signals that a committee has formed a judgement, and the Nobel committee may "
              "form a similar judgement for similar reasons. The decomposition should be "
              "read as an accounting of predictive content, and the counterfactual as a "
              "description of how rankings move, not as the effect of an intervention.")

    para(doc, "Finally, field assignment is derived from OpenAlex topics, which are "
              "themselves inferred. Interdisciplinary careers are assigned to more than one "
              "field when their profile warrants it, which is the right treatment for "
              "ranking but complicates the interpretation of field-specific probabilities. "
              "The four categories are also not equally stable institutionally: the "
              "economics prize was created in 1969 and is not, strictly, a Nobel Prize, a "
              "distinction we note but do not model.")


def conclusion(doc, N):
    doc.add_paragraph("7 Conclusion", style="Heading 1")
    para(doc, "We have argued that the Nobel Prize is best understood as a field-year "
              "discrete choice among an institutionally defined population, and we have "
              "built the data infrastructure that makes that formulation testable: a prize "
              "ladder recovered from the laureates' own award histories, a causally timed "
              "person-year panel over four fields and eight decades, and two estimators "
              "that treat the decision as a choice rather than as a classification.")
    para(doc, "The substantive finding is that recognition, once started, is largely "
              "self-propelling. The prize sequence dominates every bibliometric alternative; "
              "academic descent from a laureate adds an independent increment; institutional "
              "reputation adds nothing once the sequence is known; and citation impact, the "
              "currency of the field, is a better instrument for describing the pool than "
              "for identifying the winners. That configuration is what a cumulative-advantage "
              "process would look like from the outside, and it suggests that the interesting "
              "question for future work is not whether the Nobel is predictable but where in "
              "the ladder the conversion from achievement to recognition occurs.")
    para(doc, "The machinery is deliberately transferable. The same construction applies to "
              "any field with a documented award structure and a bibliographic index, "
              "including prizes in mathematics, computing and the social sciences, and to "
              "national academies whose elections are recorded. We release the ladder, the "
              "panel, the estimators and the forecast, in the hope that the next iteration "
              "of this question will be tested by someone else's data rather than by our "
              "own judgement.")


def declarations(doc, N):
    doc.add_paragraph("Declarations", style="Heading 1")
    for head, txt in [
        ("Funding", "No funding was received for conducting this study."),
        ("Competing interests", "The author has no competing interests to declare."),
        ("Ethics approval", "Not applicable. The study uses publicly available data on "
                            "public figures and involves no human subjects."),
        ("Data availability", "The prize ladder, the person-year panel, all estimation "
                              "scripts and the fitted forecasts are available in the "
                              "replication package accompanying this manuscript. The "
                              "underlying sources are the Nobel Prize API, Wikidata, "
                              "Crossref and OpenAlex, all of which are openly accessible."),
        ("Code availability", "Python code implementing data collection, linkage, panel "
                              "construction, estimation and evaluation is provided in the "
                              "replication package."),
        ("Author contributions", "ClawsGO Science Agent designed the study, collected and "
                                 "curated the data, implemented the models, conducted the "
                                 "analyses and wrote the manuscript."),
    ]:
        p = doc.add_paragraph()
        p.paragraph_format.first_line_indent = Cm(0)
        p.paragraph_format.space_after = Pt(4)
        r = p.add_run(head + ". ")
        r.bold = True
        p.add_run(txt)


REFS = [
    "Acuna, D. E., Allesina, S., & Kording, K. P. (2012). Future impact: Predicting "
    "scientific success. Nature, 489(7415), 201-202.",
    "Allison, P. D. (1982). Discrete-time methods for the analysis of event histories. "
    "Sociological Methodology, 13, 61-98.",
    "Allison, P. D., Long, J. S., & Krauze, T. K. (1982). Cumulative advantage and "
    "inequality in science. American Sociological Review, 47(5), 615-625.",
    "Angelopoulos, A. N., & Bates, S. (2023). Conformal prediction: A gentle introduction. "
    "Foundations and Trends in Machine Learning, 16(4), 494-591.",
    "Azoulay, P., Stuart, T., & Wang, Y. (2014). Matthew: Effect or fable? Management "
    "Science, 60(1), 92-109.",
    "Borjas, G. J., & Doran, K. B. (2015). Prizes and productivity: How winning the Fields "
    "Medal affects scientific output. Journal of Human Resources, 50(3), 728-758.",
    "Cao, Z., Qin, T., Liu, T.-Y., Tsai, M.-F., & Li, H. (2007). Learning to rank: From "
    "pairwise approach to listwise approach. In Proceedings of the 24th International "
    "Conference on Machine Learning (pp. 129-136).",
    "Chen, L., Sun, Y., & Cao, C. (2023). A two-fold evaluation in science: the case of "
    "Nobel Prize. Scientometrics, 128(11), 6267-6291.",
    "Clauset, A., Larremore, D. B., & Sinatra, R. (2017). Data-driven predictions in the "
    "science of science. Science, 355(6324), 477-480.",
    "Cole, S., & Cole, J. R. (1967). Scientific output and recognition: A study in the "
    "operation of the reward system in science. American Sociological Review, 32(3), "
    "377-390.",
    "Fortunato, S., Bergstrom, C. T., Börner, K., Evans, J. A., Helbing, D., Milojević, S., "
    "et al. (2018). Science of science. Science, 359(6379), eaao0185.",
    "Gallotti, R., & De Domenico, M. (2019). Effects of homophily and academic reputation in "
    "the nomination and selection of Nobel laureates. Scientific Reports, 9, 17304.",
    "Gingras, Y., & Wallace, M. L. (2010). Why it has become more difficult to predict "
    "Nobel Prize winners: A bibliometric analysis of nominees and winners of the chemistry "
    "and physics prizes (1901-2007). Scientometrics, 82(2), 401-412.",
    "Hirsch, J. E. (2005). An index to quantify an individual's scientific research output. "
    "Proceedings of the National Academy of Sciences, 102(46), 16569-16572.",
    "Jones, B. F., & Weinberg, B. A. (2011). Age dynamics in scientific creativity. "
    "Proceedings of the National Academy of Sciences, 108(47), 18910-18914.",
    "Ke, G., Meng, Q., Finley, T., Wang, T., Chen, W., Ma, W., Ye, Q., & Liu, T.-Y. (2017). "
    "LightGBM: A highly efficient gradient boosting decision tree. Advances in Neural "
    "Information Processing Systems, 30, 3146-3154.",
    "Li, J., Yin, Y., Fortunato, S., & Wang, D. (2019). A dataset of publication records "
    "for Nobel laureates. Scientific Data, 6, 33.",
    "Luce, R. D. (1959). Individual Choice Behavior: A Theoretical Analysis. New York: "
    "Wiley.",
    "Mazloumian, A., Eom, Y.-H., Helbing, D., Lozano, S., & Fortunato, S. (2011). How "
    "citation boosts promote scientific paradigm shifts and Nobel Prizes. PLoS ONE, 6(5), "
    "e18975.",
    "McFadden, D. (1974). Conditional logit analysis of qualitative choice behavior. In P. "
    "Zarembka (Ed.), Frontiers in Econometrics (pp. 105-142). New York: Academic Press.",
    "Merton, R. K. (1968). The Matthew effect in science. Science, 159(3810), 56-63.",
    "Plackett, R. L. (1975). The analysis of permutations. Journal of the Royal Statistical "
    "Society: Series C, 24(2), 193-202.",
    "Priem, J., Piwowar, H., & Orr, R. (2022). OpenAlex: A fully-open index of scholarly "
    "works, authors, venues, institutions, and concepts. arXiv preprint arXiv:2205.01833.",
    "Schlagberger, E. M., Bornmann, L., & Bauer, J. (2016). At what institutions did Nobel "
    "laureates do their prize-winning work? An analysis of biographical information on "
    "Nobel laureates from 1994 to 2014. Scientometrics, 109(2), 723-767.",
    "Sinatra, R., Wang, D., Deville, P., Song, C., & Barabási, A.-L. (2016). Quantifying the "
    "evolution of individual scientific impact. Science, 354(6312), aaf5239.",
    "Stephan, P. E., & Levin, S. G. (1993). Age and the Nobel Prize revisited. "
    "Scientometrics, 28(3), 387-399.",
    "Vovk, V., Gammerman, A., & Shafer, G. (2005). Algorithmic Learning in a Random World. "
    "New York: Springer.",
    "Wang, D., Song, C., & Barabási, A.-L. (2013). Quantifying long-term scientific impact. "
    "Science, 342(6154), 127-132.",
    "Wang, Y., Jones, B. F., & Wang, D. (2019). Early-career setback and future career "
    "impact. Nature Communications, 10, 4331.",
    "Way, S. F., Morgan, A. C., Clauset, A., & Larremore, D. B. (2017). The misleading "
    "narrative of the canonical faculty productivity trajectory. Proceedings of the "
    "National Academy of Sciences, 114(44), E9216-E9223.",
    "Zuckerman, H. (1977). Scientific Elite: Nobel Laureates in the United States. New York: "
    "Free Press.",
]


def references(doc, N):
    doc.add_paragraph("References", style="Heading 1")
    for r in REFS:
        p = doc.add_paragraph()
        p.paragraph_format.first_line_indent = Cm(-0.75)
        p.paragraph_format.left_indent = Cm(0.75)
        p.paragraph_format.space_after = Pt(4)
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        run = p.add_run(r)
        run.font.size = Pt(10)
