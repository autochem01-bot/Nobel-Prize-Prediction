#!/usr/bin/env python3
"""Compose the Scientometrics manuscript and save it as .docx."""

from __future__ import annotations

import sys
from pathlib import Path

from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Cm, Pt

sys.path.insert(0, str(Path(__file__).resolve().parent))
from build import caption, new_document, para, rich  # noqa: E402
import nums  # noqa: E402
import sec_back  # noqa: E402
import sec_front  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
FIG = ROOT / "figures"
OUT = ROOT / "manuscript"
OUT.mkdir(exist_ok=True)


def fig(doc, name, label, cap, width=16.0, max_h=19.5):
    from PIL import Image
    iw, ih = Image.open(FIG / name).size
    width = min(width, max_h * iw / ih)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = Cm(0)
    p.paragraph_format.space_before = Pt(12)
    p.paragraph_format.keep_with_next = True
    p.add_run().add_picture(str(FIG / name), width=Cm(width))
    caption(doc, label, cap, above=False)


def front_matter(doc):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = Cm(0)
    r = p.add_run("Scientometrics")
    r.italic = True
    r.font.size = Pt(11)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = Cm(0)
    p.paragraph_format.space_before = Pt(18)
    p.paragraph_format.space_after = Pt(14)
    r = p.add_run("Who Gets the Call? A Field-Year Discrete-Choice Model of "
                  "Nobel Recognition across Physics, Chemistry, Medicine and Economics")
    r.bold = True
    r.font.size = Pt(16)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = Cm(0)
    p.paragraph_format.space_after = Pt(2)
    r = p.add_run("ClawsGO Science Agent")
    r.font.size = Pt(12)

    for line in ["ClawsGO Science Harness", "Princeton, NJ, USA",
                 "e-mail: agent@clawsgo.ai"]:
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.first_line_indent = Cm(0)
        p.paragraph_format.space_after = Pt(2)
        r = p.add_run(line)
        r.font.size = Pt(10)

    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0)
    p.paragraph_format.space_before = Pt(20)
    r = p.add_run("ORCID: 0000-0000-0000-0000")
    r.font.size = Pt(10)


def build() -> Path:
    N = nums.load()
    doc = new_document()
    front_matter(doc)
    sec_front.abstract(doc, N)
    sec_front.introduction(doc, N)
    sec_front.related(doc, N)
    sec_front.data(doc, N)
    fig(doc, "fig01_universe.png", "Fig. 1",
        "Construction of the study universe. Nobel records define the outcome; the "
        "laureates' own award histories define the prize ladder; Crossref and OpenAlex "
        "supply career histories; the panel is the cross of people and years.",
        width=15.0)
    sec_front.methods(doc, N)
    sec_back.results(doc, N, fig)
    sec_back.discussion(doc, N)
    sec_back.conclusion(doc, N)
    sec_back.declarations(doc, N)
    sec_back.references(doc, N)

    path = OUT / "Nobel_Recognition_Scientometrics.docx"
    doc.save(path)
    return path


if __name__ == "__main__":
    p = build()
    print(p)
