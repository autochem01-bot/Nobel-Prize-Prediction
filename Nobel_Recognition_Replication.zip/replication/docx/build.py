#!/usr/bin/env python3
"""Assemble the Scientometrics manuscript as a .docx in Springer submission format:
A4, 2.5 cm margins, Times New Roman 12 pt, 1.5 line spacing, continuous line
numbers, numbered headings, captions in Scientometrics style."""

from __future__ import annotations

import json
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

ROOT = Path(__file__).resolve().parent.parent
FIG = ROOT / "figures"
RES = ROOT / "results"
OUT = ROOT / "manuscript"


def set_cell_border(cell, **kwargs):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    borders = OxmlElement("w:tcBorders")
    for edge, spec in kwargs.items():
        el = OxmlElement(f"w:{edge}")
        for k, v in spec.items():
            el.set(qn(f"w:{k}"), str(v))
        borders.append(el)
    tcPr.append(borders)


def add_line_numbers(section):
    sectPr = section._sectPr
    ln = OxmlElement("w:lnNumType")
    ln.set(qn("w:countBy"), "1")
    ln.set(qn("w:restart"), "continuous")
    sectPr.append(ln)


def add_page_numbers(section):
    p = section.footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run()
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), "PAGE")
    run._r.addnext(fld)


def style_document(doc: Document) -> None:
    st = doc.styles["Normal"]
    st.font.name = "Times New Roman"
    st.font.size = Pt(12)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    pf = st.paragraph_format
    pf.line_spacing_rule = WD_LINE_SPACING.ONE_POINT_FIVE
    pf.space_before = Pt(0)
    pf.space_after = Pt(6)
    pf.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    pf.first_line_indent = Cm(0.5)

    for name, size, before, after in [("Heading 1", 13, 18, 8), ("Heading 2", 12, 14, 6),
                                      ("Heading 3", 12, 10, 4)]:
        h = doc.styles[name]
        h.font.name = "Times New Roman"
        h.font.size = Pt(size)
        h.font.bold = True
        h.font.italic = name == "Heading 3"
        h.font.color.rgb = RGBColor(0, 0, 0)
        h.paragraph_format.space_before = Pt(before)
        h.paragraph_format.space_after = Pt(after)
        h.paragraph_format.keep_with_next = True
        h.paragraph_format.first_line_indent = Cm(0)


def para(doc, text, style=None, indent=True, size=None, align=None, italic=False,
         space_after=None, bold=False):
    p = doc.add_paragraph(style=style)
    run = p.add_run(text)
    run.bold = bold
    run.italic = italic
    if size:
        run.font.size = Pt(size)
    if align:
        p.alignment = align
    if not indent:
        p.paragraph_format.first_line_indent = Cm(0)
    if space_after is not None:
        p.paragraph_format.space_after = Pt(space_after)
    return p


def rich(doc, parts, indent=True, size=None, align=None, space_after=None):
    """parts: list of (text, {'b':,'i':}) tuples."""
    p = doc.add_paragraph()
    for text, fmt in parts:
        r = p.add_run(text)
        r.bold = fmt.get("b", False)
        r.italic = fmt.get("i", False)
        if size:
            r.font.size = Pt(size)
    if align:
        p.alignment = align
    if not indent:
        p.paragraph_format.first_line_indent = Cm(0)
    if space_after is not None:
        p.paragraph_format.space_after = Pt(space_after)
    return p


def caption(doc, label, text, above=True, size=10):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.first_line_indent = Cm(0)
    p.paragraph_format.space_before = Pt(10 if above else 4)
    p.paragraph_format.space_after = Pt(4 if above else 12)
    p.paragraph_format.keep_with_next = above
    r = p.add_run(label + " ")
    r.bold = True
    r.font.size = Pt(size)
    r2 = p.add_run(text)
    r2.font.size = Pt(size)
    return p


def table(doc, df, widths=None, font=9, header_bold=True, align=None, note=None):
    t = doc.add_table(rows=1, cols=len(df.columns))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    tblPr = t._tbl.tblPr
    layout = OxmlElement("w:tblLayout")
    layout.set(qn("w:type"), "fixed")
    tblPr.append(layout)
    trPr = t.rows[0]._tr.get_or_add_trPr()
    th = OxmlElement("w:tblHeader")
    trPr.append(th)
    for row in t.rows:
        rp = row._tr.get_or_add_trPr()
        cs = OxmlElement("w:cantSplit")
        rp.append(cs)
    hdr = t.rows[0].cells
    for j, c in enumerate(df.columns):
        hdr[j].text = ""
        p = hdr[j].paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after = Pt(2)
        p.paragraph_format.space_before = Pt(2)
        r = p.add_run(str(c))
        r.bold = header_bold
        r.font.size = Pt(font)
        r.font.name = "Times New Roman"
    for _, row in df.iterrows():
        cells = t.add_row().cells
        t.rows[-1]._tr.get_or_add_trPr().append(OxmlElement("w:cantSplit"))
        for j, v in enumerate(row):
            cells[j].text = ""
            p = cells[j].paragraphs[0]
            p.alignment = (align[j] if align else
                           (WD_ALIGN_PARAGRAPH.LEFT if j == 0 else WD_ALIGN_PARAGRAPH.CENTER))
            p.paragraph_format.space_after = Pt(1)
            p.paragraph_format.space_before = Pt(1)
            r = p.add_run(str(v))
            r.font.size = Pt(font)
            r.font.name = "Times New Roman"
    if widths:
        for j, w in enumerate(widths):
            t.columns[j].width = Cm(w)
        for row in t.rows:
            for j, w in enumerate(widths):
                row.cells[j].width = Cm(w)
    if note:
        p = doc.add_paragraph()
        p.paragraph_format.first_line_indent = Cm(0)
        p.paragraph_format.space_before = Pt(3)
        p.paragraph_format.space_after = Pt(12)
        r = p.add_run(note)
        r.font.size = Pt(8.5)
        r.italic = True
    return t


def new_document() -> Document:
    doc = Document()
    s = doc.sections[0]
    s.page_height, s.page_width = Cm(29.7), Cm(21.0)
    for m in ("top_margin", "bottom_margin"):
        setattr(s, m, Cm(2.5))
    s.left_margin = s.right_margin = Cm(2.5)
    style_document(doc)
    add_line_numbers(s)
    add_page_numbers(s)
    return doc
