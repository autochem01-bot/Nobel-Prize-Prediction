"""Load every number the manuscript quotes, once."""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
RES = ROOT / "results"
DATA = ROOT / "data"


def _csv(name):
    p = RES / name
    return pd.read_csv(p) if p.exists() else pd.DataFrame()


def load() -> dict:
    N = {}
    N["summary"] = json.load(open(RES / "summary.json")) if (RES / "summary.json").exists() else {}

    ev = _csv("eval_hazard.csv")
    es = _csv("eval_softmax.csv")
    for key, df, col in [("h", ev, "p_lgbm"), ("s", es, "p_soft")]:
        if len(df):
            d = df[df.model == col] if ("model" in df and (df.model == col).any()) else df
            N[f"auc_{key}"] = d.auc.mean()
            N[f"rank_{key}"] = d.rank_pct.mean()
            N[f"hit5_{key}"] = d.hit5.mean()
            N[f"hit10_{key}"] = d.hit10.mean()
            N[f"base_{key}"] = d.base.mean()
    for nm, key in [("w5_pct", "cit"), ("n_prizes", "prize")]:
        d = ev[ev.model == nm] if "model" in ev else pd.DataFrame()
        if len(d):
            N[f"auc_{key}"] = d.auc.mean()
            N[f"hit10_{key}"] = d.hit10.mean()
            N[f"rank_{key}"] = d.rank_pct.mean()

    pf = _csv("eval_by_field.csv")
    N["byfield"] = pf

    N["hit_curve"] = _csv("hit_curve.csv")
    N["ablation"] = _csv("ablation.csv")
    N["conformal"] = _csv("conformal.csv")
    N["decomposition"] = _csv("decomposition.csv")
    N["counterfactual"] = _csv("reputation_counterfactual.csv")
    N["forecast"] = _csv("forecast.csv")
    N["km"] = _csv("km_by_award.csv")
    N["event"] = _csv("event_study.csv")
    N["panel_summary"] = N["summary"]

    L = pd.read_csv(DATA / "laureates.csv")
    L = L[L.category.isin(["Physics", "Chemistry", "Physiology or Medicine",
                           "Economic Sciences"])]
    N["n_laureates"] = L.laureate_id.nunique()
    N["by_cat"] = L.drop_duplicates("laureate_id").category.value_counts().to_dict()

    M = pd.read_csv(DATA / "laureate_match.csv")
    N["n_matched"] = int(M.oa_id.notna().sum())
    N["match_rate"] = N["n_matched"] / len(M)

    R = pd.read_csv(DATA / "roster.csv")
    N["n_roster"] = R.qid.nunique()
    N["n_awards"] = R.award_q.nunique()
    N["n_award_rows"] = len(R)
    RM = pd.read_csv(DATA / "roster_match.csv")
    N["n_roster_matched"] = int(RM.oa_id.notna().sum())
    N["roster_rate"] = N["n_roster_matched"] / len(RM)

    A = pd.read_csv(DATA / "roster_advisors.csv")
    N["n_advisor_edges"] = len(A)
    N["n_with_advisor"] = A.qid.nunique()

    LR = pd.read_csv(DATA / "laureates.csv")
    LR["qid"] = LR.wikidata.str.rsplit("/", n=1).str[-1]
    L4 = LR[LR.category.isin(["Physics", "Chemistry", "Physiology or Medicine",
                              "Economic Sciences"])].drop_duplicates("laureate_id")
    N["roster_covers"] = int(L4.qid.isin(set(R.qid)).sum())
    N["roster_cover_rate"] = N["roster_covers"] / len(L4)

    P = pd.read_parquet(DATA / "panel.parquet")
    N["panel"] = P
    N["n_py"] = len(P)
    N["n_people"] = P.oa_id.nunique()
    N["n_events"] = int(P.y_nobel.sum())
    N["cat_desc"] = P.groupby("cat").agg(
        py=("y_nobel", "size"), ppl=("oa_id", "nunique"), ev=("y_nobel", "sum")).reset_index()
    return N
