#!/usr/bin/env python3
"""Stage 17 - publication figures."""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

ROOT = Path(__file__).resolve().parent.parent
RES = ROOT / "results"
FIG = ROOT / "figures"
FIG.mkdir(exist_ok=True)

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 8, "axes.labelsize": 8.5,
    "axes.titlesize": 8.5, "xtick.labelsize": 7.5, "ytick.labelsize": 7.5,
    "legend.fontsize": 7, "axes.spines.top": False, "axes.spines.right": False,
    "figure.dpi": 200, "savefig.dpi": 400, "savefig.bbox": "tight",
    "axes.grid": False, "grid.alpha": 0.25, "grid.linewidth": 0.5,
})
OK = {"blue": "#0072B2", "orange": "#E69F00", "green": "#009E73", "red": "#D55E00",
      "purple": "#CC79A7", "sky": "#56B4E9", "yellow": "#F0E442", "grey": "#666666"}
W = 17.0
W2 = 8.2


def save(fig, name):
    fig.savefig(FIG / name)
    plt.close(fig)
    print("  ", name)


def fig_universe():
    meta = json.load(open(RES / "summary.json")) if (RES / "summary.json").exists() else {}
    fig, ax = plt.subplots(figsize=(15.5 / 2.54, 7.4 / 2.54))
    ax.set_xlim(0.1, 9.9); ax.set_ylim(2.02, 9.45); ax.axis("off")
    boxes = [
        (7.85, "Nobel Prize API\n765 laureates, 1901-2026"),
        (5.95, "Wikidata\n93 prize rosters, 9,945 award holders"),
        (4.05, "Crossref + OpenAlex\nDOI to authorship, 7,834 linked"),
        (2.15, "OpenAlex author records\ncareer histories, 1960-2026"),
    ]
    for y, t in boxes:
        ax.add_patch(FancyBboxPatch((0.25, y), 4.3, 1.45, boxstyle="round,pad=0.06",
                                    fc="#EEF4F9", ec=OK["blue"], lw=0.8))
        ax.text(2.4, y + 0.72, t, ha="center", va="center", fontsize=6.8)
    for y in [7.85, 5.95, 4.05]:
        ax.annotate("", xy=(2.4, y - 0.08), xytext=(2.4, y + 0.19),
                    arrowprops=dict(arrowstyle="-|>", lw=0.8, color=OK["grey"],
                                    shrinkA=0, shrinkB=0))
    ax.add_patch(FancyBboxPatch((5.6, 3.45), 4.1, 3.3, boxstyle="round,pad=0.08",
                                fc="#FDF2E3", ec=OK["orange"], lw=1.0))
    ax.text(7.65, 6.35, "Person-year panel", ha="center", va="center", fontsize=8,
            fontweight="bold")
    ax.text(7.65, 5.05, "%.0fk person-years\n%s people\n%d Nobel events" %
            (meta.get("n_rows", 0) / 1000, f"{meta.get('people', 0):,}",
             meta.get("events", 0)),
            ha="center", va="center", fontsize=7, linespacing=1.5)
    ax.annotate("", xy=(5.55, 4.6), xytext=(4.6, 4.35),
                arrowprops=dict(arrowstyle="-|>", lw=1.0, color=OK["orange"],
                                shrinkA=0, shrinkB=0))
    ax.text(7.65, 2.85, "walk-forward estimation\nhazard  |  committee softmax",
            ha="center", va="center", fontsize=6.6, color=OK["grey"], style="italic")
    save(fig, "fig01_universe.png")


def fig_ladder():
    K = pd.read_csv(RES / "km_by_award.csv")
    ten = K[K.t == 10].sort_values("s").head(8)
    fig, ax = plt.subplots(figsize=(W2 / 2.54, 8.2 / 2.54))
    cmap = plt.cm.viridis(np.linspace(0, 0.85, len(ten)))
    for (a, c) in zip(ten.award, cmap):
        g = K[(K.award == a) & (K.t <= 25)]
        ax.step(g.t, g.s, where="post", lw=1.1, color=c, label=a)
    ax.set_xlabel("Years since the prize")
    ax.set_ylabel("Probability of no Nobel yet")
    ax.set_ylim(0.5, 1.02)
    ax.set_xlim(0, 25)
    ax.grid(axis="y", lw=0.4)
    ax.legend(loc="upper center", bbox_to_anchor=(0.45, -0.22), ncol=2, fontsize=4.7,
              frameon=False, handlelength=1.4, columnspacing=1.0, labelspacing=0.25)
    save(fig, "fig02_ladder.png")


def fig_event():
    es = pd.read_csv(RES / "event_study.csv")
    fig, axes = plt.subplots(1, 2, figsize=(W / 2.54, 6.0 / 2.54))
    ax = axes[0]
    ax.plot(es.rel, es.lcc, "o-", ms=2.5, lw=1, color=OK["blue"])
    ax.axvline(0, color=OK["grey"], lw=0.6, ls="--")
    ax.set_xlabel("Years relative to the Nobel"); ax.set_ylabel("log(1 + cumulative citations)")
    ax.grid(lw=0.4)
    ax = axes[1]
    ax.plot(es.rel, es.cc, "s-", ms=2.5, lw=1, color=OK["orange"])
    ax.axvline(0, color=OK["grey"], lw=0.6, ls="--")
    ax.set_xlabel("Years relative to the Nobel"); ax.set_ylabel("within-cohort citation percentile")
    ax.grid(lw=0.4)
    save(fig, "fig03_event.png")


def fig_performance():
    E = pd.read_csv(RES / "eval_by_field.csv")
    cats = ["Physics", "Chemistry", "Medicine", "Economics"]
    models = ["p_lgbm", "softmax"] if "softmax" in set(E.model) else ["p_lgbm"]
    fig, axes = plt.subplots(1, 2, figsize=(W / 2.54, 6.2 / 2.54))
    for ax, col, ttl in [(axes[0], "hit10", "(a) recall@10"),
                         (axes[1], "hit5", "(b) recall@5")]:
        x = np.arange(len(cats)); wd = 0.8 / len(models)
        for i, m in enumerate(models):
            sub = E[(E.model == m)].set_index("cat").reindex(cats)
            ax.bar(x + i * wd - 0.4 + wd / 2, sub[col] * 100, wd * 0.92,
                   label=m.replace("p_lgbm", "hazard").replace("softmax", "committee"),
                   color=[OK["blue"], OK["orange"]][i % 2])
        ax.set_xticks(x); ax.set_xticklabels(cats, rotation=15)
        ax.set_ylabel("% of laureates retrieved"); ax.set_title(ttl, loc="left")
        ax.grid(axis="y", lw=0.4)
    axes[0].legend(frameon=False)
    save(fig, "fig04_performance.png")


def fig_ablation():
    A = pd.read_csv(RES / "ablation.csv")
    full = A[A.dropped == "none"].auc.iloc[0]
    A = A[A.dropped != "none"].sort_values("auc")
    fig, ax = plt.subplots(figsize=(W2 / 2.54, 5.6 / 2.54))
    ax.barh(A.dropped, (full - A.auc) * 1000, color=OK["red"], height=0.6)
    ax.set_xlabel(r"loss in AUC when the block is removed ($\times 10^{-3}$)")
    ax.grid(axis="x", lw=0.4)
    save(fig, "fig05_ablation.png")


def fig_calibration():
    P = pd.read_parquet(RES / "pred_hazard.parquet")
    p = P.p_lgbm.values
    y = P.y_nobel.values
    q = np.quantile(p, np.linspace(0, 1, 21))
    q = np.unique(q)
    idx = np.digitize(p, q[1:-1])
    xs, ys = [], []
    for k in range(len(q) - 1):
        m = idx == k
        if m.sum() > 300:
            xs.append(p[m].mean()); ys.append(y[m].mean())
    fig, ax = plt.subplots(figsize=(W2 / 2.54, 6.0 / 2.54))
    ax.plot([1e-5, 1e-1], [1e-5, 1e-1], ls="--", lw=0.7, color=OK["grey"])
    ax.plot(xs, ys, "o-", ms=3, lw=1, color=OK["blue"])
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel("Predicted annual probability"); ax.set_ylabel("Observed frequency")
    ax.grid(lw=0.4, which="both")
    save(fig, "fig06_calibration.png")


def fig_conformal():
    C = pd.read_csv(RES / "conformal.csv")
    fig, axes = plt.subplots(1, 2, figsize=(W / 2.54, 5.6 / 2.54))
    g = C.groupby("alpha").coverage.mean()
    axes[0].plot(1 - g.index, g.values, "o-", color=OK["blue"], ms=3, lw=1)
    axes[0].plot([0.5, 0.95], [0.5, 0.95], "--", lw=0.7, color=OK["grey"])
    axes[0].set_xlabel("Nominal coverage"); axes[0].set_ylabel("Empirical coverage")
    axes[0].grid(lw=0.4)
    g2 = C.groupby("alpha").set_frac.mean()
    axes[1].plot(1 - g2.index, g2.values, "s-", color=OK["orange"], ms=3, lw=1)
    axes[1].set_xlabel("Nominal coverage"); axes[1].set_ylabel("Set size, share of risk set")
    axes[1].grid(lw=0.4)
    save(fig, "fig07_conformal.png")


def fig_forecast():
    F = pd.read_csv(RES / "forecast.csv")
    cats = ["Physics", "Chemistry", "Medicine", "Economics"]
    fig, axes = plt.subplots(1, 4, figsize=(W / 2.54, 6.2 / 2.54))
    fig.subplots_adjust(wspace=0.62)
    for ax, c in zip(axes, cats):
        g = F[F.cat == c].nlargest(7, "p5").iloc[::-1]
        short = [str(n).split()[-1][:16] for n in g.name]
        ax.barh(range(len(g)), g.p5 * 100, color=OK["blue"], height=0.62)
        ax.set_yticks(range(len(g)))
        ax.set_yticklabels(short, fontsize=5.2)
        ax.set_title(c, fontsize=7)
        ax.set_xlabel("% (2027-31)", fontsize=6)
        ax.tick_params(axis="x", labelsize=5.6)
        ax.tick_params(axis="y", length=0, pad=1)
        ax.set_ylim(-0.7, len(g) - 0.3)
    save(fig, "fig08_forecast.png")


if __name__ == "__main__":
    for fn in [fig_universe, fig_ladder, fig_event, fig_performance, fig_ablation,
               fig_calibration, fig_conformal, fig_forecast]:
        try:
            fn()
        except Exception as exc:  # noqa: BLE001
            print("  skip", fn.__name__, exc)
