#!/usr/bin/env python3
"""Stage 6 - hydrate candidate identifiers from the OpenAlex single-entity endpoint.

Single-entity retrievals are free and unlimited, so the whole pool can be built
without spending API credits. Output is an append-only JSONL cache keyed by the
identifier we queried, which makes the stage fully resumable.
"""

from __future__ import annotations

import json
import sys
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
CACHE = ROOT / "cache" / "oax"
CACHE.mkdir(parents=True, exist_ok=True)
DATA = ROOT / "data"
OUT = CACHE / "authors.jsonl"
UA = {"User-Agent": "nobel-scientometrics/1.0 (mailto:researcher@example.org)"}
BASE = "https://api.openalex.org/authors/"


def compact(a: dict, key: str) -> dict:
    topics = sorted(a.get("topics") or [], key=lambda t: -t.get("count", 0))[:10]
    affs = []
    for af in a.get("affiliations") or []:
        inst = af.get("institution") or {}
        affs.append({"id": (inst.get("id") or "").rsplit("/", 1)[-1],
                     "name": inst.get("display_name"),
                     "country": inst.get("country_code"),
                     "years": af.get("years") or []})
    return {
        "key": key,
        "id": a["id"].rsplit("/", 1)[-1],
        "name": a.get("display_name"),
        "alt_names": (a.get("display_name_alternatives") or [])[:6],
        "orcid": (a.get("orcid") or "").replace("https://orcid.org/", "") or None,
        "works_count": a.get("works_count"),
        "cited_by_count": a.get("cited_by_count"),
        "h_index": (a.get("summary_stats") or {}).get("h_index"),
        "i10": (a.get("summary_stats") or {}).get("i10_index"),
        "mean2y": (a.get("summary_stats") or {}).get("2yr_mean_citedness"),
        "counts_by_year": a.get("counts_by_year") or [],
        "topics": [{"name": t.get("display_name"),
                    "field": ((t.get("field") or {}).get("id") or "").rsplit("/", 1)[-1],
                    "domain": ((t.get("domain") or {}).get("id") or "").rsplit("/", 1)[-1],
                    "count": t.get("count")} for t in topics],
        "affiliations": affs,
        "last_known": [i.get("display_name") for i in a.get("last_known_institutions") or []],
    }


def fetch(key: str, tries: int = 3) -> dict | None:
    kind, ident = key.split(":", 1)
    url = BASE + (ident if kind == "A" else "orcid:" + ident)
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers=UA)
            with urllib.request.urlopen(req, timeout=30) as r:
                return compact(json.loads(r.read()), key)
        except urllib.error.HTTPError as exc:
            if exc.code in (404, 400):
                return {"key": key, "id": None}
            time.sleep(1.5 * (i + 1))
        except Exception:  # noqa: BLE001
            time.sleep(1.5 * (i + 1))
    return {"key": key, "id": None}


def main() -> None:
    src = Path(sys.argv[1]) if len(sys.argv) > 1 else DATA / "candidate_ids.csv"
    ids = pd.read_csv(src)
    done = set()
    if OUT.exists():
        with OUT.open() as fh:
            for line in fh:
                try:
                    done.add(json.loads(line)["key"])
                except Exception:  # noqa: BLE001
                    pass
    todo = [k for k in ids.key.tolist() if k not in done]
    print(f"total {len(ids)}  done {len(done)}  todo {len(todo)}")

    t0 = time.time()
    with OUT.open("a") as fh, ThreadPoolExecutor(max_workers=10) as pool:
        futs = {pool.submit(fetch, k): k for k in todo}
        for n, f in enumerate(as_completed(futs), 1):
            fh.write(json.dumps(f.result()) + "\n")
            if n % 2000 == 0:
                rate = n / (time.time() - t0)
                print(f"  {n}/{len(todo)}  {rate:.1f}/s  eta {(len(todo)-n)/rate/60:.0f} min",
                      flush=True)
                fh.flush()


if __name__ == "__main__":
    main()
