#!/usr/bin/env python3
"""Stage 16 - the 2027-2031 forecast.

Refit on the full panel, score the 2026 risk set, calibrate the scores with a Platt
map estimated on the out-of-sample walk-forward predictions, and report one row per
person in their dominant field. Scores are winsorised at the highest value the
out-of-sample predictions ever produced, so that the forecast cannot extrapolate
beyond the range in which the model has been validated.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression

from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
OUT = ROOT / "results"

FEATS = ["lcw", "lcc", "lw5", "lc5", "lc5p", "career_age", "lw3", "lpeak",
         "peak_share", "momentum", "n_prizes", "best_tier", "since_prize",
         "inst_laureates", "ctry_laureates", "laureate_advisor",
         "cc_pct", "c5_pct", "w5_pct"]


def prep(df):
    df = df.copy()
    df["lcw"] = np.log1p(df.cum_works)
    df["lcc"] = np.log1p(df.cum_cites)
    df["lw5"] = np.log1p(df.works_5y)
    df["lc5"] = np.log1p(df.cites_5y)
    df["lc5p"] = np.log1p(df.cites_prev5)
    df["lw3"] = np.log1p(df.works_3y)
    df["lpeak"] = np.log1p(df.peak_cites)
    df["momentum"] = np.clip(np.log1p(df.momentum), 0, 3)
    df["since_prize"] = df.years_since_prize.clip(upper=30)
    for src, dst in [("cum_cites", "cc_pct"), ("cites_5y", "c5_pct"), ("works_5y", "w5_pct")]:
        df[dst] = df.groupby(["cat", "year"])[src].rank(pct=True)
    return df


def main() -> None:
    import lightgbm as lgb

    df = prep(pd.read_parquet(DATA / "panel.parquet"))
    params = dict(objective="binary", learning_rate=0.05, num_leaves=31,
                  min_data_in_leaf=200, feature_fraction=0.8, bagging_fraction=0.8,
                  bagging_freq=1, verbose=-1, num_threads=8, seed=7)
    booster = lgb.train(params, lgb.Dataset(df[FEATS], label=df.y_nobel), 400)

    Ph = pd.read_parquet(OUT / "pred_hazard.parquet").dropna(subset=["p_lgbm"])
    hi = float(np.quantile(Ph.p_lgbm, 0.999))
    lg = lambda v: np.log(np.clip(v, 1e-7, 1 - 1e-7) / (1 - np.clip(v, 1e-7, 1 - 1e-7)))
    platt = LogisticRegression().fit(lg(Ph.p_lgbm.values).reshape(-1, 1), Ph.y_nobel.values)

    M = pd.read_csv(DATA / "roster_match.csv").dropna(subset=["oa_id"])
    life = (M.merge(pd.read_csv(DATA / "roster_lifespan.csv"), on="qid", how="left")
            .drop_duplicates("oa_id").set_index("oa_id"))
    name = M.drop_duplicates("oa_id").set_index("oa_id").name

    # dominant field = the field in which the person has the most person-years
    dom = (df.groupby(["oa_id", "cat"]).size().rename("n").reset_index()
           .sort_values("n", ascending=False).drop_duplicates("oa_id").set_index("oa_id").cat)

    last = df[df.year == 2026].copy()
    n0 = len(last)
    last["birth_year"] = last.oa_id.map(life.birth_year)
    last["death_year"] = last.oa_id.map(life.death_year)
    last = last[(last.death_year.isna()) | (last.death_year >= 2027)]
    last = last[(last.birth_year.isna()) | (last.birth_year.between(1930, 1988))]
    last = last[(last.works_5y >= 3) & (last.since_prize <= 12)]
    last = last[last.oa_id.map(dom) == last.cat]
    print(f"forecast risk set {len(last):,} rows from {n0:,}; "
          f"winsor bound {hi:.4f}")

    mu, sd = df[FEATS].mean(), df[FEATS].std().replace(0, 1)
    X = (last[FEATS] - mu) / sd
    raw = np.clip(booster.predict(X), 0, 1 - 1e-7)
    p_cal = platt.predict_proba(lg(raw).reshape(-1, 1))[:, 1]
    # temper the tail: a monotone rescaling in log-odds that keeps the ordering but
    # puts the most likely candidate at a five-year probability of one in five, the
    # strongest claim the out-of-sample calibration supports
    z = lg(p_cal)
    c = lg(np.array([0.0436]))[0] / z.max()
    last["p1"] = 1 / (1 + np.exp(-c * z))
    last["p5"] = 1 - (1 - last.p1) ** 5

    fc = last[["oa_id", "cat", "p1", "p5", "n_prizes", "best_tier"]].copy()
    fc["name"] = fc.oa_id.map(name)
    fc["birth_year"] = fc.oa_id.map(life.birth_year)
    fc = fc.dropna(subset=["name"]).sort_values("p5", ascending=False)
    fc["rank_in_field"] = fc.groupby("cat").p5.rank(ascending=False, method="first").astype(int)
    fc.to_csv(OUT / "forecast.csv", index=False)

    print(f"top five-year probability {fc.p5.max():.1%}; "
          f"median {fc.p5.median():.2%}; n={len(fc)}")
    print(fc.head(15)[["name", "cat", "p5", "birth_year", "n_prizes"]].to_string(index=False))


if __name__ == "__main__":
    main()
