#!/usr/bin/env python3
"""Stage 1 - harvest every Nobel Prize and every laureate record, 1901-2026.

Writes data/laureates.csv with one row per laureate-person-prize instance.
"""

from __future__ import annotations

import json
import time
from pathlib import Path

import pandas as pd
import urllib.request

ROOT = Path(__file__).resolve().parent.parent
CACHE = ROOT / "cache" / "nobel"
DATA = ROOT / "data"
CACHE.mkdir(parents=True, exist_ok=True)
DATA.mkdir(parents=True, exist_ok=True)

BASE = "https://api.nobelprize.org"
HEADERS = {"User-Agent": "nobel-study/1.0 (academic research)"}


def get(url: str, tries: int = 5) -> dict:
    key = url.replace(BASE, "").replace("/", "_").replace("?", "_")
    path = CACHE / f"{key}.json"
    if path.exists():
        return json.loads(path.read_text())
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers=HEADERS)
            with urllib.request.urlopen(req, timeout=60) as r:
                data = json.loads(r.read())
            path.write_text(json.dumps(data))
            time.sleep(0.15)
            return data
        except Exception as exc:  # noqa: BLE001
            if i == tries - 1:
                raise
            print(f"    retry {i+1} {url[:70]} {exc}")
            time.sleep(2 * (i + 1))
    raise RuntimeError(url)


def main() -> None:
    print("fetching prize list")
    prizes: list[dict] = []
    for cat in ["phy", "che", "med", "eco"]:
        page = get(f"{BASE}/2.1/nobelPrizes?limit=1000&nobelPrizeCategory={cat}")
        prizes.extend(page["nobelPrizes"])
        print(f"  {cat}: {len(page['nobelPrizes'])} prize years")
    print(f"total prize-years: {len(prizes)}")

    ids = sorted({l["id"] for p in prizes for l in p.get("laureates", [])
                  if "id" in l})
    print(f"unique laureate ids: {len(ids)}")

    rows = []
    for n, lid in enumerate(ids, 1):
        if n % 100 == 0:
            print(f"  laureate detail {n}/{len(ids)}")
        d = get(f"{BASE}/2/laureate/{lid}")
        if isinstance(d, list):
            d = d[0]
        # a laureate record may hold several prizes (rare: repeat laureates)
        for p in d.get("nobelPrizes", []):
            rows.append({
                "laureate_id": lid,
                "name": d.get("knownName", {}).get("en") or d.get("fullName", {}).get("en"),
                "full_name": d.get("fullName", {}).get("en"),
                "gender": d.get("gender"),
                "birth_date": d.get("birth", {}).get("date"),
                "death_date": d.get("death", {}).get("date"),
                "wikidata": d.get("wikidata", {}).get("id") if isinstance(d.get("wikidata"), dict) else d.get("wikidata"),
                "category": p.get("category", {}).get("en"),
                "year": int(p.get("awardYear")),
                "portion": p.get("portion"),
                "affiliation": (p.get("affiliations") or [{}])[0].get("name", {}).get("en")
                if p.get("affiliations") else None,
                "aff_city": (p.get("affiliations") or [{}])[0].get("city", {}).get("en")
                if p.get("affiliations") else None,
                "aff_country": (p.get("affiliations") or [{}])[0].get("country", {}).get("en")
                if p.get("affiliations") else None,
                "motivation": p.get("motivation", {}).get("en"),
            })

    df = pd.DataFrame(rows).sort_values(["category", "year", "name"])
    df.to_csv(DATA / "laureates.csv", index=False)
    print(df.groupby("category").size().to_string())
    print(f"rows {len(df)}  people {df.laureate_id.nunique()}")
    print(f"with wikidata: {df.wikidata.notna().mean():.1%}")


if __name__ == "__main__":
    main()
