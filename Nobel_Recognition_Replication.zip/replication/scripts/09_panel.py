#!/usr/bin/env python3
"""Stage 9 - build the person-year panel.

Every feature is a function of information observable on 1 January of the reference
year: cumulative output and citations up to the previous year, recent momentum,
career age, topic structure, and the prior laureate production of the author's
institution and country.
"""

from __future__ import annotations

import json
import re
import unicodedata
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
CACHE = ROOT / "cache" / "oax"

Y0, Y1 = 1975, 2026
CAT_FIELD = {"Physics": {"31"}, "Chemistry": {"16"},
             "Medicine": {"27", "13", "24", "28", "30"}, "Economics": {"20"}}


def norm_inst(s: str) -> str:
    s = unicodedata.normalize("NFKD", str(s or ""))
    s = "".join(c for c in s if not unicodedata.combining(c)).lower()
    s = re.sub(r"\b(university|universite|universitat|universidad|college|institute|"
               r"institut|school|of|the|and|for|national|research|center|centre)\b", " ", s)
    return re.sub(r"[^a-z]", "", s)


def load_authors() -> list[dict]:
    out = []
    with (CACHE / "authors.jsonl").open() as fh:
        for line in fh:
            try:
                r = json.loads(line)
            except Exception:  # noqa: BLE001
                continue
            if r.get("id"):
                out.append(r)
    return out


def category_of(rec: dict) -> str | None:
    counts: dict[str, int] = {}
    for t in rec.get("topics", []):
        f = t.get("field")
        if f:
            counts[f] = counts.get(f, 0) + (t.get("count") or 0)
    if not counts:
        return None
    # weight fields by topic share, then map onto the four Nobel categories
    score = {c: sum(v for f, v in counts.items() if f in fs) for c, fs in CAT_FIELD.items()}
    best = max(score, key=score.get)
    return best if score[best] > 0 else None


def build(recs: list[dict]) -> pd.DataFrame:
    rows = []
    for r in recs:
        cat = category_of(r)
        if not cat:
            continue
        cy = {int(d["year"]): (d.get("works_count") or 0, d.get("cited_by_count") or 0)
              for d in r.get("counts_by_year", []) if d.get("year")}
        if not cy:
            continue
        years = np.arange(Y0, Y1 + 1)
        works = np.array([cy.get(y, (0, 0))[0] for y in years], dtype=np.float32)
        cites = np.array([cy.get(y, (0, 0))[1] for y in years], dtype=np.float32)
        first = next((y for y in years if cy.get(y, (0, 0))[0] > 0), None)
        if first is None:
            continue
        cw, cc = np.cumsum(works), np.cumsum(cites)
        cw_prev = np.concatenate([[0], cw[:-1]])
        cc_prev = np.concatenate([[0], cc[:-1]])
        w5 = np.convolve(works, np.ones(5), "full")[:len(years)]
        c5 = np.convolve(cites, np.ones(5), "full")[:len(years)]
        w5 = np.concatenate([[0] * 5, w5[:-5]]) if len(w5) > 5 else np.zeros_like(w5)
        c5p = np.concatenate([[0] * 10, c5[:-10]]) if len(c5) > 10 else np.zeros_like(c5)
        # institution per year: latest affiliation whose span covers the year
        aff = r.get("affiliations") or []
        inst_by_year: dict[int, str] = {}
        ctry_by_year: dict[int, str] = {}
        for a in aff:
            for y in a.get("years") or []:
                inst_by_year[int(y)] = a.get("name")
                ctry_by_year[int(y)] = a.get("country")
        last_aff = aff[0].get("name") if aff else None
        last_ctry = aff[0].get("country") if aff else None
        cur_inst, cur_ctry = last_aff, last_ctry
        for i, y in enumerate(years):
            if y < first:
                continue
            cur_inst = inst_by_year.get(y, cur_inst)
            cur_ctry = ctry_by_year.get(y, cur_ctry)
            rows.append((
                r["id"], cat, int(y),
                float(cw_prev[i]), float(cc_prev[i]), float(w5[i]), float(c5[i]),
                float(c5p[i]), float(i - (first - Y0)),
                float(np.sum(works[i:i + 3])), float(np.max(cites[:i + 1]) if i else 0),
                float(cc_prev[i] > 0 and np.max(cites[:i + 1]) / max(cc_prev[i], 1)),
                norm_inst(cur_inst), cur_ctry,
                float(r.get("h_index") or 0), float(r.get("works_count") or 0),
            ))
    cols = ["oa_id", "cat", "year", "cum_works", "cum_cites", "works_5y", "cites_5y",
            "cites_prev5", "career_age", "works_3y", "peak_cites", "peak_share",
            "inst", "country", "h_now", "works_now"]
    return pd.DataFrame(rows, columns=cols)


def main() -> None:
    recs = load_authors()
    print(f"author records: {len(recs)}")
    df = build(recs)
    print(f"person-years: {len(df):,}  authors: {df.oa_id.nunique():,}")
    print(df.cat.value_counts().to_string())

    # ---- institutional and national laureate capital, by year ----------
    L = pd.read_csv(DATA / "laureates.csv")
    L = L[L.category.isin(CAT_FIELD)]
    L["cat"] = L.category.replace({"Physiology or Medicine": "Medicine"})
    L["inst_n"] = L.affiliation.map(norm_inst)
    L["country_n"] = L.aff_country.fillna("")

    inst_hist: dict[tuple[str, str, int], int] = {}
    for cat, g in L.groupby("cat"):
        g = g.dropna(subset=["year"])
        for nm, gg in g.groupby("inst_n"):
            if not nm:
                continue
            yrs = sorted(gg.year.tolist())
            for y in range(Y0, Y1 + 1):
                inst_hist[(cat, nm, y)] = sum(1 for v in yrs if v < y)
    ctry_hist: dict[tuple[str, str, int], int] = {}
    for cat, g in L.groupby("cat"):
        for nm, gg in g.groupby("country_n"):
            if not nm:
                continue
            yrs = sorted(gg.year.tolist())
            for y in range(Y0, Y1 + 1):
                ctry_hist[(cat, nm, y)] = sum(1 for v in yrs if v < y)

    df["inst_laureates"] = [inst_hist.get((c, i, y), 0) for c, i, y in
                            zip(df.cat, df.inst, df.year)]
    df["ctry_laureates"] = [ctry_hist.get((c, k, y), 0) for c, k, y in
                            zip(df.cat, df.country.fillna(""), df.year)]

    # ---- outcome -------------------------------------------------------
    M = pd.read_csv(DATA / "laureate_match.csv")
    M = M.dropna(subset=["oa_id"])
    M["cat"] = M.category.replace({"Physiology or Medicine": "Medicine",
                                   "Economic Sciences": "Economics"})
    won = M.groupby(["oa_id", "cat"]).year.min().reset_index().rename(columns={"year": "won_year"})
    df = df.merge(won, on=["oa_id", "cat"], how="left")

    # leave the risk set after winning; keep at most 45 years of risk
    df = df[(df.won_year.isna()) | (df.year <= df.won_year)]
    df = df[df.career_age <= 45]

    df["y_nobel"] = ((df.won_year == df.year)).astype("int8")
    df.to_parquet(DATA / "panel.parquet", index=False)
    print(f"kept {len(df):,} person-years; events {int(df.y_nobel.sum())}")
    print(df.groupby("cat").y_nobel.sum().to_string())


if __name__ == "__main__":
    main()
