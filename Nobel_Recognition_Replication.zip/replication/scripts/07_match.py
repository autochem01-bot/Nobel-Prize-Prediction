#!/usr/bin/env python3
"""Stage 7 - link laureates to OpenAlex author records.

Exact ORCID match first; otherwise normalised name match restricted to the laureate's
own field, with ambiguity resolved towards the most cited record.
"""

from __future__ import annotations

import json
import re
import unicodedata
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
CACHE = ROOT / "cache" / "oax"

CAT_FIELD = {"Physics": {"31"}, "Chemistry": {"16"}, "Physiology or Medicine": {"27", "13", "24", "28", "30"},
             "Economic Sciences": {"20", "14"}}


def norm(s: str) -> str:
    s = unicodedata.normalize("NFKD", str(s))
    s = "".join(c for c in s if not unicodedata.combining(c))
    s = s.lower().replace("ø", "o").replace("ł", "l").replace("đ", "d")
    s = re.sub(r"[^a-z\s]", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def name_keys(full: str, known: str | None) -> set[str]:
    out = set()
    for s in {full, known}:
        if not s:
            continue
        n = norm(s)
        parts = n.split()
        if len(parts) >= 2:
            out.add(f"{parts[0]} {parts[-1]}")
            out.add(f"{parts[-1]} {parts[0]}")
            if len(parts) >= 3:
                out.add(f"{parts[0]} {parts[1]} {parts[-1]}")
    return out


def load_authors() -> pd.DataFrame:
    recs = [json.loads(l) for l in (CACHE / "authors.jsonl").open()]
    rows = []
    for r in recs:
        if not r.get("id"):
            continue
        rows.append({
            "oa_id": r["id"], "name": r["name"], "orcid": r.get("orcid"),
            "cited": r.get("cited_by_count") or 0, "works": r.get("works_count") or 0,
            "h": r.get("h_index"),
            "field": (r["topics"][0]["field"] if r.get("topics") else None),
            "fields": ",".join(sorted({t["field"] for t in r.get("topics", []) if t.get("field")})),
        })
    return pd.DataFrame(rows)


def main() -> None:
    L = pd.read_csv(DATA / "laureates.csv")
    L = L[L.category.isin(CAT_FIELD)].copy()
    L = L.sort_values("year").drop_duplicates("laureate_id")
    A = load_authors()
    print(f"laureate rows {len(L)}  author records {len(A)}")

    by_orcid = {o: i for o, i in zip(A.orcid.dropna(), A.loc[A.orcid.notna(), "oa_id"])}
    idx = {}
    for _, r in A.iterrows():
        for k in name_keys(r["name"], None):
            idx.setdefault(k, []).append(_)

    matches = []
    for _, l in L.iterrows():
        oa = by_orcid.get(l.orcid) if isinstance(l.get("orcid"), str) else None
        how = "orcid" if oa else None
        if not oa:
            cands = []
            for k in name_keys(l.full_name, l["name"]):
                cands.extend(idx.get(k, []))
            cands = list(dict.fromkeys(cands))
            if cands:
                sub = A.loc[cands]
                sub = sub[sub.fields.apply(lambda x: bool(set(str(x).split(",")) & CAT_FIELD[l.category]))]
                if len(sub):
                    best = sub.sort_values("cited", ascending=False).iloc[0]
                    oa, how = best.oa_id, "name"
        matches.append({"laureate_id": l.laureate_id, "name": l["name"], "category": l.category,
                        "year": l.year, "oa_id": oa, "how": how})

    M = pd.DataFrame(matches)
    M.to_csv(DATA / "laureate_match.csv", index=False)
    print(f"matched {M.oa_id.notna().sum()} / {len(M)}")
    print(M.groupby(["category", "how"], dropna=False).size().to_string())


if __name__ == "__main__":
    main()
