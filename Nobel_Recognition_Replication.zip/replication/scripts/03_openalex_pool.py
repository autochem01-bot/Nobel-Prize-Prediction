#!/usr/bin/env python3
"""Stage 3 - pull the field universe from OpenAlex.

For each of the four Nobel fields we walk authors ordered by citations and keep a
compact record: bibliometrics, per-year output, topic composition, affiliation
history. The walk is cursor-based and resumable; every page is cached on disk.
"""

from __future__ import annotations

import json
import sys
import time
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CACHE = ROOT / "cache" / "openalex"
CACHE.mkdir(parents=True, exist_ok=True)
DATA = ROOT / "data"

API = "https://api.openalex.org/authors"
UA = "nobel-scientometrics/1.0 (mailto:researcher@example.org)"

FIELDS = {"physics": 31, "chemistry": 16, "medicine": 27, "economics": 20}
TARGET = {"physics": 30000, "chemistry": 30000, "medicine": 40000, "economics": 30000}
PER_PAGE = 200


def fetch(url: str, tries: int = 6) -> dict:
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA})
            with urllib.request.urlopen(req, timeout=90) as r:
                return json.loads(r.read())
        except Exception as exc:  # noqa: BLE001
            print(f"    retry {i+1} ({exc})")
            time.sleep(5 * (i + 1))
    raise RuntimeError(url)


def compact(a: dict) -> dict:
    topics = sorted(a.get("topics") or [], key=lambda t: -t.get("count", 0))[:8]
    affs = []
    for af in a.get("affiliations") or []:
        inst = af.get("institution") or {}
        affs.append({"id": inst.get("id"), "name": inst.get("display_name"),
                     "country": inst.get("country_code"), "years": af.get("years") or []})
    return {
        "id": a["id"].rsplit("/", 1)[-1],
        "name": a.get("display_name"),
        "orcid": (a.get("orcid") or "").replace("https://orcid.org/", "") or None,
        "works_count": a.get("works_count"),
        "cited_by_count": a.get("cited_by_count"),
        "stats": a.get("summary_stats") or {},
        "counts_by_year": a.get("counts_by_year") or [],
        "topics": [{"id": (t.get("id") or "").rsplit("/", 1)[-1],
                    "name": t.get("display_name"),
                    "field": (t.get("field") or {}).get("id", "").rsplit("/", 1)[-1]
                    if t.get("field") else None,
                    "domain": (t.get("domain") or {}).get("id", "").rsplit("/", 1)[-1]
                    if t.get("domain") else None,
                    "count": t.get("count")} for t in topics],
        "affiliations": affs,
        "last_known": [i.get("display_name") for i in a.get("last_known_institutions") or []],
    }


def run_field(key: str, fid: int, target: int) -> None:
    ck = CACHE / f"ckpt_{key}.json"
    state = json.loads(ck.read_text()) if ck.exists() else {"cursor": "*", "n": 0}
    out = CACHE / f"pool_{key}.jsonl"
    n = state["n"]
    cursor = state["cursor"]
    if cursor is None:
        print(f"  {key}: already complete ({n})")
        return
    print(f"  {key}: resume at {n} authors")
    while n < target and cursor:
        q = urllib.parse.urlencode({
            "filter": f"topics.field.id:{fid}",
            "sort": "cited_by_count:desc",
            "per_page": PER_PAGE,
            "cursor": cursor,
        })
        page = fetch(f"{API}?{q}")
        with out.open("a") as fh:
            for a in page.get("results", []):
                fh.write(json.dumps(compact(a)) + "\n")
        got = len(page.get("results", []))
        n += got
        cursor = page.get("meta", {}).get("next_cursor")
        ck.write_text(json.dumps({"cursor": cursor, "n": n}))
        if n % 2000 == 0 or got < PER_PAGE:
            print(f"    {key}: {n} authors")
        time.sleep(0.05)
    print(f"  {key}: done at {n}")


def main() -> None:
    only = sys.argv[1:] or list(FIELDS)
    for key in only:
        run_field(key, FIELDS[key], TARGET[key])


if __name__ == "__main__":
    main()
