#!/usr/bin/env python3
"""Stage 9 - define the prize roster: everyone who has won an award that Nobel
laureates themselves won. The awards are taken empirically from the laureates' own
award histories, so the universe is the prize ladder as it actually exists.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wd import sparql  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
P = ("PREFIX wd: <http://www.wikidata.org/entity/>\n"
     "PREFIX wdt: <http://www.wikidata.org/prop/direct/>\n"
     "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>\n")

BAD = re.compile(r"fellow|honorar|doctor|order of|member|hall of fame|knighthood|"
                 r"legion|prize for|medal of the|commemorative|lecture|studentship", re.I)
NOBEL = re.compile(r"nobel", re.I)


def main() -> None:
    A = pd.read_csv(DATA / "laureate_awards.csv")
    A["award_q"] = A.award.str.rsplit("/", n=1).str[-1]
    top = (A[A.award_q.notna()].groupby(["award_q", "awardLabel"]).size()
           .sort_values(ascending=False).head(160).reset_index())
    top.columns = ["award_q", "label", "n_laureates"]
    vals = " ".join("wd:" + q for q in top.award_q)
    cnt = sparql(P + f"""SELECT ?award (COUNT(DISTINCT ?p) AS ?n) WHERE {{
        VALUES ?award {{ {vals} }}
        ?p wdt:P166 ?award . ?p wdt:P31 wd:Q5 .
      }} GROUP BY ?award""")
    C = pd.DataFrame(cnt)
    C["award_q"] = C.award.str.rsplit("/", n=1).str[-1]
    C["n_recipients"] = C.n.astype(int)
    top = top.merge(C[["award_q", "n_recipients"]], on="award_q", how="left")
    top = top.sort_values("n_laureates", ascending=False)
    top.to_csv(DATA / "roster_awards.csv", index=False)
    print(top.head(60).to_string(max_colwidth=45))

    keep = top[(~top.label.str.contains(BAD)) & (~top.label.str.contains(NOBEL))
               & (top.n_recipients.between(30, 4000))]
    print(f"\nkept {len(keep)} awards covering "
          f"{keep.n_laureates.sum()} laureate-award links")
    keep[["award_q", "label"]].to_csv(DATA / "roster_awards_keep.csv", index=False)

    rows = []
    for q, lab in zip(keep.award_q, keep.label):
        part = []
        for i in range(3):
            try:
                part = sparql(P + f"""SELECT ?p ?when WHERE {{
                    ?p p:P166 ?st . ?st ps:P166 wd:{q} . ?p wdt:P31 wd:Q5 .
                    OPTIONAL {{ ?st pq:P585 ?when }} }}""")
                break
            except Exception as exc:  # noqa: BLE001
                print(f"    {lab[:40]}: retry {i+1} ({exc})")
        for r in part:
            r["award"] = "http://www.wikidata.org/entity/" + q
            rows.append(r)
        print(f"  {lab[:45]:47s} {len(part)}", flush=True)
    R = pd.DataFrame(rows)
    R["qid"] = R.p.str.rsplit("/", n=1).str[-1]
    R["award_q"] = R.award.str.rsplit("/", n=1).str[-1]
    R["year"] = pd.to_datetime(R.when, errors="coerce", utc=True).dt.year
    R = R[["qid", "award_q", "year"]].drop_duplicates()
    R.to_csv(DATA / "roster.csv", index=False)
    print(f"\nroster people: {R.qid.nunique():,}  awards: {R.award_q.nunique()}  "
          f"rows: {len(R):,}")


if __name__ == "__main__":
    main()
