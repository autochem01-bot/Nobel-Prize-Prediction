#!/usr/bin/env python3
"""Stage 14 - walk-forward estimation and evaluation.

Two estimators on the same strictly causal feature set:
  * a pointwise discrete-time hazard (LightGBM), refitted every year;
  * a listwise softmax over the risk set of each field-year ("committee choice"),
    a neural model refitted on expanding five-year blocks.

Everything is evaluated on years the model never saw: ranking metrics per field,
recall-at-k against the random allocation, calibration, split-conformal coverage
and an ablation that removes one block of covariates at a time.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)

FEATS = ["lcw", "lcc", "lw5", "lc5", "lc5p", "career_age", "lw3", "lpeak",
         "peak_share", "momentum", "n_prizes", "best_tier", "since_prize",
         "inst_laureates", "ctry_laureates", "laureate_advisor",
         "cc_pct", "c5_pct", "w5_pct"]
BLOCKS = {
    "productivity": ["lcw", "lw5", "lw3", "w5_pct"],
    "impact": ["lcc", "lc5", "lc5p", "lpeak", "peak_share", "momentum", "cc_pct", "c5_pct"],
    "prizes": ["n_prizes", "best_tier", "since_prize"],
    "reputation": ["inst_laureates", "ctry_laureates"],
    "genealogy": ["laureate_advisor"],
}
T0 = 1990
KS = (1, 2, 5, 10, 20, 50, 100, 200, 400)


def prep(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["lcw"] = np.log1p(df.cum_works)
    df["lcc"] = np.log1p(df.cum_cites)
    df["lw5"] = np.log1p(df.works_5y)
    df["lc5"] = np.log1p(df.cites_5y)
    df["lc5p"] = np.log1p(df.cites_prev5)
    df["lw3"] = np.log1p(df.works_3y)
    df["lpeak"] = np.log1p(df.peak_cites)
    df["momentum"] = np.clip(np.log1p(df.momentum), 0, 3)
    df["since_prize"] = df.years_since_prize.clip(upper=30)
    for src, dst in [("cum_cites", "cc_pct"), ("cites_5y", "c5_pct"), ("works_5y", "w5_pct")]:
        df[dst] = df.groupby(["cat", "year"])[src].rank(pct=True)
    return df


def auc(y, s):
    y = np.asarray(y)
    if y.min() == y.max():
        return np.nan
    from sklearn.metrics import roc_auc_score
    return float(roc_auc_score(y, s))


def evaluate(df: pd.DataFrame, score: str) -> pd.DataFrame:
    rows = []
    for (cat, year), g in df.groupby(["cat", "year"]):
        if g.y_nobel.sum() == 0:
            continue
        s = g[score].values
        order = np.argsort(-s, kind="stable")
        rank = np.empty(len(s))
        rank[order] = np.arange(1, len(s) + 1)
        win = g.y_nobel.values == 1
        r = {"cat": cat, "year": year, "n": len(s), "events": int(win.sum()),
             "auc": auc(g.y_nobel.values, s), "base": win.mean(),
             "rank_pct": float(np.mean((rank[win] - 1) / max(len(s) - 1, 1)))}
        for k in (1, 5, 10, 25):
            r[f"hit{k}"] = float(np.mean(rank[win] <= k))
        rows.append(r)
    return pd.DataFrame(rows)


def hit_curve(df: pd.DataFrame, score: str) -> pd.DataFrame:
    out = []
    for k in KS:
        rec, rnd = [], []
        for _, g in df.groupby(["cat", "year"]):
            if g.y_nobel.sum() == 0:
                continue
            r = g[score].rank(ascending=False, method="first")
            rec.append(float((r[g.y_nobel == 1] <= k).mean()))
            rnd.append(min(k, len(g)) / len(g))
        out.append({"k": k, "recall": float(np.mean(rec)),
                    "random": float(np.mean(rnd)),
                    "lift": float(np.mean(rec) / max(np.mean(rnd), 1e-9))})
    return pd.DataFrame(out)


def fit_lgbm(tr, feats, seed=7):
    import lightgbm as lgb
    params = dict(objective="binary", learning_rate=0.05, num_leaves=31,
                  min_data_in_leaf=200, feature_fraction=0.8, bagging_fraction=0.8,
                  bagging_freq=1, verbose=-1, num_threads=8, seed=seed)
    return lgb.train(params, lgb.Dataset(tr[feats], label=tr.y_nobel), 300)


def fit_listwise(tr, feats, epochs=250, seed=7):
    import torch
    import torch.nn as nn
    torch.manual_seed(seed)
    cats = sorted(tr.cat.unique())
    cidx = {c: i for i, c in enumerate(cats)}
    groups = []
    for (cat, year), g in tr.groupby(["cat", "year"]):
        y = torch.tensor(g.y_nobel.values, dtype=torch.float32)
        if y.sum() == 0:
            continue
        groups.append((cidx[cat], torch.tensor(g[feats].values, dtype=torch.float32), y))
    mu = torch.tensor(tr[feats].mean().values, dtype=torch.float32)
    sd = torch.tensor(tr[feats].std().replace(0, 1).values, dtype=torch.float32)

    class Soft(nn.Module):
        def __init__(self, p, nc):
            super().__init__()
            self.emb = nn.Embedding(nc, 8)
            self.l1 = nn.Linear(p, 96)
            self.l2 = nn.Linear(96 + 8, 64)
            self.l3 = nn.Linear(64, 1)
        def forward(self, x, c):
            h = torch.relu(self.l1(x))
            h = torch.cat([h, self.emb(c)], dim=-1)
            return self.l3(torch.relu(self.l2(h))).squeeze(-1)

    net = Soft(len(feats), len(cats))
    opt = torch.optim.Adam(net.parameters(), lr=3e-3, weight_decay=1e-4)
    sch = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs)
    for _ in range(epochs):
        net.train()
        np.random.shuffle(groups)
        opt.zero_grad()
        tot = 0.0
        for c, x, y in groups:
            s = net((x - mu) / sd, torch.full((len(x),), c, dtype=torch.long))
            tot = tot - (torch.logsumexp(s[y > 0], dim=0) - torch.logsumexp(s, dim=0))
        (tot / len(groups)).backward()
        opt.step()
        sch.step()

    def score(gcat, g):
        net.eval()
        with torch.no_grad():
            x = torch.tensor(g[feats].values, dtype=torch.float32)
            s = net((x - mu) / sd, torch.full((len(x),), cidx.get(gcat, 0),
                                              dtype=torch.long)).numpy().astype(float)
        e = np.exp(s - s.max())
        return e / e.sum()
    return score


def main() -> None:
    df = prep(pd.read_parquet(DATA / "panel.parquet"))
    print(f"panel {len(df):,}  events {int(df.y_nobel.sum())}  years "
          f"{df.year.min()}-{df.year.max()}", flush=True)

    # ---- pointwise hazard, annual refits --------------------------------
    preds = []
    for t in range(T0, 2026):
        tr, te = df[df.year < t], df[df.year == t].copy()
        if len(te) == 0 or tr.y_nobel.sum() < 20:
            continue
        te["p_lgbm"] = fit_lgbm(tr, FEATS).predict(te[FEATS])
        preds.append(te)
    P = pd.concat(preds)
    print(f"\ntest field-years {P.groupby(['cat','year']).ngroups}  "
          f"events {int(P.y_nobel.sum())}", flush=True)

    res = {}
    for nm in ["p_lgbm", "w5_pct", "lc5", "n_prizes"]:
        e = evaluate(P, nm)
        res[nm] = e
        print(f"{nm:9s} auc {e.auc.mean():.3f}  rank% {e.rank_pct.mean():.3f}  "
              f"hit10 {e.hit10.mean():.3f}  base {e.base.mean():.4f}  "
              f"lift {e.hit10.mean()/e.base.mean():.0f}x", flush=True)
    E = pd.concat([e.assign(model=k) for k, e in res.items()])
    E.to_csv(OUT / "eval_hazard.csv", index=False)

    HC = []
    for nm in ["p_lgbm", "w5_pct", "n_prizes"]:
        hc = hit_curve(P, nm)
        hc["model"] = nm
        HC.append(hc)
    pd.concat(HC).to_csv(OUT / "hit_curve.csv", index=False)

    # ---- listwise committee model, five-year blocks ---------------------
    lw = []
    for b in range(T0, 2026, 5):
        tr, te = df[df.year < b], df[(df.year >= b) & (df.year < b + 5)].copy()
        if len(te) == 0 or tr.y_nobel.sum() < 20:
            continue
        sc = fit_listwise(tr, FEATS)
        parts = []
        for (cat, year), g in te.groupby(["cat", "year"]):
            g = g.copy()
            g["p_soft"] = sc(cat, g)
            parts.append(g)
        lw.append(pd.concat(parts))
        print(f"  softmax block {b}-{b+4}  n={len(te):,}", flush=True)
    L = pd.concat(lw)
    e = evaluate(L, "p_soft")
    e.assign(model="softmax").to_csv(OUT / "eval_softmax.csv", index=False)
    print(f"softmax   auc {e.auc.mean():.3f}  rank% {e.rank_pct.mean():.3f}  "
          f"hit10 {e.hit10.mean():.3f}  base {e.base.mean():.4f}  "
          f"lift {e.hit10.mean()/e.base.mean():.0f}x", flush=True)
    hc = hit_curve(L, "p_soft")
    hc["model"] = "softmax"
    pd.concat([pd.concat(HC), hc]).to_csv(OUT / "hit_curve.csv", index=False)

    # ---- per-field summary ---------------------------------------------
    per_field = (E.groupby(["model", "cat"])
                 .agg(auc=("auc", "mean"), rank_pct=("rank_pct", "mean"),
                      hit5=("hit5", "mean"), hit10=("hit10", "mean"),
                      base=("base", "mean"), events=("events", "sum"),
                      n=("n", "mean"))
                 .reset_index())
    pf2 = (e.groupby("cat").agg(auc=("auc", "mean"), rank_pct=("rank_pct", "mean"),
                                hit5=("hit5", "mean"), hit10=("hit10", "mean"),
                                base=("base", "mean"), events=("events", "sum"),
                                n=("n", "mean")).reset_index().assign(model="softmax"))
    per_field = pd.concat([per_field, pf2])
    per_field.to_csv(OUT / "eval_by_field.csv", index=False)
    print(per_field.to_string(index=False))

    # ---- ablation, three seeds -----------------------------------------
    abl = []
    for drop, feats_drop in list(BLOCKS.items()) + [("none", [])]:
        keep = [f for f in FEATS if f not in feats_drop]
        aucs, h10 = [], []
        for seed in (7, 17, 27):
            ps = []
            for t in range(2010, 2026):
                tr, te = df[df.year < t], df[df.year == t].copy()
                if len(te) == 0:
                    continue
                te["p"] = fit_lgbm(tr, keep, seed=seed).predict(te[keep])
                ps.append(te)
            ee = evaluate(pd.concat(ps), "p")
            aucs.append(ee.auc.mean()); h10.append(ee.hit10.mean())
        abl.append({"dropped": drop, "auc": float(np.mean(aucs)),
                    "auc_seed_sd": float(np.std(aucs)),
                    "hit10": float(np.mean(h10))})
        print(f"  drop {drop:13s} auc {np.mean(aucs):.4f}  hit10 {np.mean(h10):.3f}",
              flush=True)
    A = pd.DataFrame(abl)
    A["delta_auc"] = A.loc[A.dropped == "none", "auc"].iloc[0] - A.auc
    A.to_csv(OUT / "ablation.csv", index=False)

    # ---- split conformal -------------------------------------------------
    conf = []
    for alpha in [0.05, 0.1, 0.2, 0.3, 0.5, 0.7, 0.9]:
        for t in range(2000, 2026):
            past = E[(E.model == "p_lgbm") & (E.year < t)]
            if len(past) < 20:
                continue
            q = float(np.quantile(past.rank_pct, 1 - alpha))
            cur = E[(E.model == "p_lgbm") & (E.year == t)]
            conf.append({"alpha": alpha, "year": t, "threshold": q,
                         "coverage": float((cur.rank_pct <= q).mean()),
                         "set_frac": float(np.clip(q, 0, 1))})
    C = pd.DataFrame(conf)
    C.to_csv(OUT / "conformal.csv", index=False)
    print(C.groupby("alpha").agg(nominal=("alpha", lambda s: 1 - s.iloc[0]),
                                 coverage=("coverage", "mean"),
                                 set_frac=("set_frac", "mean")).to_string())

    P.to_parquet(OUT / "pred_hazard.parquet", index=False)
    L.to_parquet(OUT / "pred_softmax.parquet", index=False)
    json.dump({"n_rows": int(len(df)), "events": int(df.y_nobel.sum()),
               "people": int(df.oa_id.nunique()),
               "test_events": int(P.y_nobel.sum()),
               "test_field_years": int(P.groupby(["cat", "year"]).ngroups),
               "mean_risk_set": float(P.groupby(["cat", "year"]).size().mean())},
              open(OUT / "summary.json", "w"))


if __name__ == "__main__":
    main()
