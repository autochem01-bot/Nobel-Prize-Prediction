#!/usr/bin/env python3
"""Stage 10 - resolve every roster member to an OpenAlex author id.

Order of preference: an explicit OpenAlex id on Wikidata, an ORCID, a resolution
already obtained for a laureate, and finally the Crossref -> work -> authorship vote
used for laureates. Output is resumable.
"""

from __future__ import annotations

import json
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wd import sparql  # noqa: E402
import importlib.util  # noqa: E402

spec = importlib.util.spec_from_file_location(
    "laur", Path(__file__).resolve().parent / "08_laureate_ids.py")
laur = importlib.util.module_from_spec(spec)
spec.loader.exec_module(laur)  # reuse norm / get / crossref_candidates / work_authors

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
OUT = DATA / "roster_match_raw.jsonl"
P = ("PREFIX wd: <http://www.wikidata.org/entity/>\n"
     "PREFIX wdt: <http://www.wikidata.org/prop/direct/>\n"
     "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>\n"
     "PREFIX schema: <http://schema.org/>\n")
LOCK = threading.Lock()


def people_meta(qids: list[str]) -> pd.DataFrame:
    rows = []
    for i in range(0, len(qids), 400):
        chunk = qids[i:i + 400]
        vals = " ".join("wd:" + q for q in chunk)
        got = sparql(P + f"""SELECT ?p ?name ?orcid ?oax ?desc WHERE {{
            VALUES ?p {{ {vals} }}
            ?p rdfs:label ?name . FILTER(lang(?name) = "en")
            OPTIONAL {{ ?p wdt:P496 ?orcid }}
            OPTIONAL {{ ?p wdt:P10283 ?oax }}
            OPTIONAL {{ ?p schema:description ?desc . FILTER(lang(?desc) = "en") }}
          }}""")
        for r in got:
            rows.append({"qid": r["p"].rsplit("/", 1)[-1], "name": r["name"],
                         "orcid": r.get("orcid", "").rsplit("/", 1)[-1] or None,
                         "oax": (r.get("oax") or "").rsplit("/", 1)[-1] or None,
                         "desc": r.get("desc")})
        print(f"  meta {i + len(chunk)}/{len(qids)}", flush=True)
    return pd.DataFrame(rows).drop_duplicates("qid")


def resolve_one(r) -> dict:
    if isinstance(r.oax, str) and r.oax.startswith("A"):
        return {"qid": r.qid, "oa_id": r.oax, "how": "wd_oax"}
    if isinstance(r.orcid, str) and r.orcid:
        d = laur.get("https://api.openalex.org/authors/orcid:" + r.orcid)
        if d and d.get("id"):
            return {"qid": r.qid, "oa_id": d["id"].rsplit("/", 1)[-1], "how": "orcid"}
    name = str(r.name)
    t = laur.norm(name).split()
    if len(t) < 2:
        return {"qid": r.qid, "oa_id": None, "how": "none"}
    fam, giv = t[-1], t[0][:1]
    votes: dict[str, int] = {}
    for doi in laur.crossref_candidates(name, fam, giv, rows=20)[:4]:
        for aid, disp in laur.work_authors(doi):
            n = laur.norm(disp).split()
            if n and n[-1] == fam and n[0][0] == giv:
                votes[aid] = votes.get(aid, 0) + 1
    if votes:
        aid = max(votes, key=votes.get)
        return {"qid": r.qid, "oa_id": aid, "how": "doi", "n_votes": votes[aid]}
    return {"qid": r.qid, "oa_id": None, "how": "none"}


def main() -> None:
    R = pd.read_csv(DATA / "roster.csv")
    qids = sorted(set(R.qid))
    meta_path = DATA / "roster_meta.csv"
    if meta_path.exists():
        M = pd.read_csv(meta_path)
    else:
        M = people_meta(qids)
        M.to_csv(meta_path, index=False)
    print(f"roster {len(qids)}  meta {len(M)}  orcid {M.orcid.notna().sum()}  "
          f"wd_oax {M.oax.notna().sum()}")

    # laureate resolutions transfer directly
    L = pd.read_csv(DATA / "laureates.csv")
    L["qid"] = L.wikidata.str.rsplit("/", n=1).str[-1]
    LM = pd.read_csv(DATA / "laureate_match.csv").merge(
        L[["laureate_id", "qid"]], on="laureate_id", how="left")
    transfer = {q: o for q, o in zip(LM.qid, LM.oa_id) if isinstance(o, str) and o}
    done = {}
    if OUT.exists():
        for line in OUT.open():
            try:
                r = json.loads(line)
                if r.get("oa_id"):
                    done[r["qid"]] = r["oa_id"]
            except Exception:  # noqa: BLE001
                pass
    for q, o in transfer.items():
        done.setdefault(q, o)
    print(f"pre-resolved: transfer {len(transfer)}  cached {len(done)}")

    todo = M[~M.qid.isin(done)]
    print(f"todo {len(todo)}", flush=True)
    t0 = time.time()
    with OUT.open("a") as fh, ThreadPoolExecutor(max_workers=12) as pool:
        futs = [pool.submit(resolve_one, r) for r in todo.itertuples()]
        for n, f in enumerate(as_completed(futs), 1):
            try:
                rec = f.result()
            except Exception as exc:  # noqa: BLE001
                print("  fail", exc, flush=True)
                continue
            with LOCK:
                fh.write(json.dumps(rec) + "\n")
            if n % 100 == 0:
                fh.flush()
                el = time.time() - t0
                print(f"  {n}/{len(todo)}  {n/el:.2f}/s  eta {(len(todo)-n)/(n/el)/60:.0f} min",
                      flush=True)

    allrec = []
    if OUT.exists():
        allrec = [json.loads(l) for l in OUT.open() if l.strip()]
    D = pd.DataFrame(allrec)
    D = D[D.oa_id.notna() & D.oa_id.astype(str).str.startswith("A")]
    for q, o in transfer.items():
        if q not in set(D.qid):
            D = pd.concat([D, pd.DataFrame([{"qid": q, "oa_id": o, "how": "laureate"}])])
    D = D.drop_duplicates("qid")
    D.merge(M[["qid", "name", "orcid"]], on="qid", how="left").to_csv(
        DATA / "roster_match.csv", index=False)
    print(f"resolved {len(D)} / {len(M)} roster people ({len(D)/len(M):.1%})")
    print(D.how.value_counts().to_string())


if __name__ == "__main__":
    main()
