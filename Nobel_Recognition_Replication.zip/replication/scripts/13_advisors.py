#!/usr/bin/env python3
"""Stage 13 - doctoral ancestry for the roster (Wikidata P184), used to measure how
much of a candidate's standing runs through academic genealogy to a laureate."""

from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wd import sparql  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
P = ("PREFIX wd: <http://www.wikidata.org/entity/>\n"
     "PREFIX wdt: <http://www.wikidata.org/prop/direct/>\n")


def main() -> None:
    qids = sorted(set(pd.read_csv(DATA / "roster.csv").qid))
    rows = []
    for i in range(0, len(qids), 300):
        chunk = qids[i:i + 300]
        vals = " ".join("wd:" + q for q in chunk)
        for _ in range(3):
            try:
                got = sparql(P + f"""SELECT ?p ?adv WHERE {{
                    VALUES ?p {{ {vals} }}
                    ?p wdt:P184 ?adv . }}""")
                break
            except Exception as exc:  # noqa: BLE001
                print("  retry", exc)
                got = []
        for r in got:
            rows.append({"qid": r["p"].rsplit("/", 1)[-1],
                         "advisor": r["adv"].rsplit("/", 1)[-1]})
        print(f"  {i + len(chunk)}/{len(qids)}  edges {len(rows)}", flush=True)
    A = pd.DataFrame(rows).drop_duplicates()
    A.to_csv(DATA / "roster_advisors.csv", index=False)
    print(f"advisor edges {len(A):,}  people with advisor {A.qid.nunique():,}")


if __name__ == "__main__":
    main()
