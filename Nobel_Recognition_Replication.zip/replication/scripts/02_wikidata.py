#!/usr/bin/env python3
"""Stage 2 - enrich laureates with Wikidata identifiers.

ORCID (P496) drives exact OpenAlex matching; doctoral advisors (P184) and the
awards received (P166) feed the network and pedigree features.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wd import sparql  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"

PREFIX = """
PREFIX wd: <http://www.wikidata.org/entity/>
PREFIX wdt: <http://www.wikidata.org/prop/direct/>
PREFIX p: <http://www.wikidata.org/prop/>
PREFIX ps: <http://www.wikidata.org/prop/statement/>
PREFIX pq: <http://www.wikidata.org/prop/qualifier/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
"""


def chunks(seq, n):
    for i in range(0, len(seq), n):
        yield seq[i:i + n]


def main() -> None:
    laureates = pd.read_csv(DATA / "laureates.csv")
    qids = sorted(set(laureates.wikidata.dropna().str.replace("http://www.wikidata.org/entity/", "", regex=False)))
    print(f"{len(qids)} laureate QIDs")

    # ---- ORCID ---------------------------------------------------------
    orc = []
    for i, batch in enumerate(chunks(qids, 120), 1):
        q = PREFIX + f"""
SELECT ?p ?orcid WHERE {{
  VALUES ?p {{ {' '.join('wd:' + q for q in batch)} }}
  ?p wdt:P496 ?orcid .
}}"""
        rows = sparql(q)
        orc.extend(rows)
        print(f"  orcid batch {i}: {len(rows)}")
    orcid = pd.DataFrame(orc).rename(columns={"p": "wikidata", "orcid": "orcid"})
    orcid["wikidata"] = orcid.wikidata.str.rsplit("/", n=1).str[-1]
    orcid = orcid.drop_duplicates("wikidata")
    orcid.to_csv(DATA / "laureate_orcid.csv", index=False)
    print(f"ORCID found for {len(orcid)} laureates ({len(orcid)/len(qids):.1%})")

    # ---- doctoral advisors ---------------------------------------------
    adv = []
    for i, batch in enumerate(chunks(qids, 120), 1):
        q = PREFIX + f"""
SELECT ?p ?advisor ?advisorLabel WHERE {{
  VALUES ?p {{ {' '.join('wd:' + q for q in batch)} }}
  ?p wdt:P184 ?advisor .
  SERVICE wikibase:label {{ bd:serviceParam wikibase:language "en". }}
}}"""
        rows = sparql(q)
        adv.extend(rows)
        print(f"  advisor batch {i}: {len(rows)}")
    advisors = pd.DataFrame(adv)
    if len(advisors):
        advisors["p"] = advisors.p.str.rsplit("/", n=1).str[-1]
        advisors["advisor"] = advisors.advisor.str.rsplit("/", n=1).str[-1]
        advisors = advisors.drop_duplicates(["p", "advisor"])
    advisors.to_csv(DATA / "laureate_advisors.csv", index=False)
    print(f"advisor edges: {len(advisors)}")

    # ---- awards received (pedigree) ------------------------------------
    awards = []
    for i, batch in enumerate(chunks(qids, 120), 1):
        q = PREFIX + f"""
SELECT ?p ?award ?awardLabel ?when WHERE {{
  VALUES ?p {{ {' '.join('wd:' + q for q in batch)} }}
  ?p p:P166 ?st .
  ?st ps:P166 ?award .
  OPTIONAL {{ ?st pq:P585 ?when . }}
  SERVICE wikibase:label {{ bd:serviceParam wikibase:language "en". }}
}}"""
        rows = sparql(q)
        awards.extend(rows)
        print(f"  award batch {i}: {len(rows)}")
    aw = pd.DataFrame(awards)
    if len(aw):
        aw["p"] = aw.p.str.rsplit("/", n=1).str[-1]
        aw["award"] = aw.award.str.rsplit("/", n=1).str[-1]
        aw["year"] = pd.to_datetime(aw.when, errors="coerce", format="mixed").dt.year
    aw.to_csv(DATA / "laureate_awards.csv", index=False)
    print(f"award statements: {len(aw)}  dated: {aw.year.notna().mean():.1%}")


if __name__ == "__main__":
    main()
