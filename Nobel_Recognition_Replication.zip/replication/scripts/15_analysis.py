#!/usr/bin/env python3
"""Stage 15 - substantive analyses.

  * survival from a given prize to the Nobel, by prize;
  * merit trajectories around the award (event study);
  * hazard regressions that separate merit from reputation and genealogy;
  * a reputation counterfactual: re-rank candidates with reputation held at the
    cohort median and measure how much the ranking moves.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)

FEATS = ["lcw", "lcc", "lw5", "lc5", "lc5p", "career_age", "lw3", "lpeak",
         "peak_share", "momentum", "n_prizes", "best_tier", "since_prize",
         "inst_laureates", "ctry_laureates", "laureate_advisor",
         "cc_pct", "c5_pct", "w5_pct"]
MERIT = ["lcw", "lcc", "lw5", "lc5", "lc5p", "lw3", "lpeak", "peak_share",
         "momentum", "cc_pct", "c5_pct", "w5_pct", "career_age"]
REP = ["inst_laureates", "ctry_laureates", "laureate_advisor"]
PRIZE = ["n_prizes", "best_tier", "since_prize"]


def prep(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["lcw"] = np.log1p(df.cum_works)
    df["lcc"] = np.log1p(df.cum_cites)
    df["lw5"] = np.log1p(df.works_5y)
    df["lc5"] = np.log1p(df.cites_5y)
    df["lc5p"] = np.log1p(df.cites_prev5)
    df["lw3"] = np.log1p(df.works_3y)
    df["lpeak"] = np.log1p(df.peak_cites)
    df["momentum"] = np.clip(np.log1p(df.momentum), 0, 3)
    df["since_prize"] = df.years_since_prize.clip(upper=30)
    for src, dst in [("cum_cites", "cc_pct"), ("cites_5y", "c5_pct"), ("works_5y", "w5_pct")]:
        df[dst] = df.groupby(["cat", "year"])[src].rank(pct=True)
    return df


def km(duration: np.ndarray, event: np.ndarray):
    order = np.argsort(duration)
    d, e = duration[order], event[order]
    times, surv, at_risk = [0], [1.0], [len(d)]
    s = 1.0
    for t in np.unique(d[e == 1]):
        n_risk = int((d >= t).sum())
        n_ev = int(((d == t) & (e == 1)).sum())
        s *= (1 - n_ev / max(n_risk, 1))
        times.append(int(t))
        surv.append(s)
    return np.array(times), np.array(surv)


def main() -> None:
    df = prep(pd.read_parquet(DATA / "panel.parquet"))
    M = pd.read_csv(DATA / "roster_match.csv")
    R = pd.read_csv(DATA / "roster.csv").dropna(subset=["year"])

    # ---- 1. prize -> Nobel survival ------------------------------------
    L4 = pd.read_csv(DATA / "laureates.csv")
    L4 = L4[L4.category.isin(["Physics", "Chemistry", "Physiology or Medicine",
                              "Economic Sciences"])]
    L4["qid"] = L4.wikidata.str.rsplit("/", n=1).str[-1]
    nobel = L4.groupby("qid").year.min()
    Aw = pd.read_csv(DATA / "roster_awards_keep.csv")
    lab = dict(zip(Aw.award_q, Aw.label))
    R2 = R.merge(M[["qid", "oa_id"]], on="qid", how="inner")
    R2["nobel_year"] = R2.qid.map(nobel)
    curves = []
    for a, g in R2.groupby("award_q"):
        if g.oa_id.nunique() < 80:
            continue
        g = g.drop_duplicates(["oa_id"])
        dur = (g.nobel_year - g.year).where(g.nobel_year.notna(), 2026 - g.year)
        dur = dur.clip(lower=0)
        ev = g.nobel_year.notna() & (g.nobel_year >= g.year)
        t, s = km(dur.values.astype(int), ev.values.astype(int))
        for tt, ss in zip(t, s):
            curves.append({"award": lab.get(a, a), "award_q": a, "t": int(tt), "s": float(ss),
                           "n": int(len(g))})
    K = pd.DataFrame(curves)
    K.to_csv(OUT / "km_by_award.csv", index=False)
    top = (K[K.t <= 20].groupby("award").s.min().sort_values().head(10).index.tolist())
    print("most predictive prizes (10y conversion):")
    print(K[(K.t == 10) & (K.award.isin(top))].sort_values("s")[["award", "s", "n"]].to_string(index=False))

    # ---- 2. event study: merit around the Nobel ------------------------
    W = df[df.y_nobel == 1][["oa_id", "year"]].rename(columns={"year": "ny"})
    ev = df.merge(W, on="oa_id", how="inner")
    ev["rel"] = ev.year - ev.ny
    es = (ev[ev.rel.between(-10, 10)]
          .groupby("rel").agg(lcc=("lcc", "mean"), cc=("cc_pct", "mean"),
                              lw5=("lw5", "mean"), n=("rel", "size")).reset_index())
    es.to_csv(OUT / "event_study.csv", index=False)
    print(es.to_string(index=False))

    # ---- 3. hazard regression ------------------------------------------
    import statsmodels.api as sm
    d = df.copy()
    for c in FEATS:
        d[c] = (d[c] - d[c].mean()) / (d[c].std() or 1)
    d["cat_c"] = pd.Categorical(d.cat)
    X = pd.get_dummies(d[FEATS + ["cat_c"]], drop_first=True, dtype=float)
    y = d.y_nobel.values
    try:
        m = sm.Logit(y, sm.add_constant(X)).fit(disp=0, maxiter=200)
        coef = pd.DataFrame({"term": X.columns, "b": m.params[1:], "se": m.bse[1:],
                             "z": m.tvalues[1:], "p": m.pvalues[1:]})
        coef["or"] = np.exp(coef.b)
        coef.sort_values("b", key=abs, ascending=False).to_csv(OUT / "hazard_logit.csv", index=False)
        print("\nlargest standardised effects (odds ratio per SD):")
        print(coef.reindex(coef.b.abs().sort_values(ascending=False).index)
              .head(12)[["term", "or", "p"]].to_string(index=False))
    except Exception as exc:  # noqa: BLE001
        print("logit failed", exc)

    # ---- 4. reputation counterfactual -----------------------------------
    import lightgbm as lgb
    tr, te = d[d.year < 2020], d[d.year >= 2020].copy()
    params = dict(objective="binary", learning_rate=0.05, num_leaves=31,
                  min_data_in_leaf=200, feature_fraction=0.8, bagging_fraction=0.8,
                  bagging_freq=1, verbose=-1, num_threads=8, seed=7)
    booster = lgb.train(params, lgb.Dataset(tr[FEATS], label=tr.y_nobel), 300)
    te["p_full"] = booster.predict(te[FEATS])
    cf = te.copy()
    for c in REP:
        cf[c] = tr[c].median()
    te["p_med"] = booster.predict(cf[FEATS])
    churn, moved = [], []
    for (cat, year), g in te.groupby(["cat", "year"]):
        a = g.p_full.rank(ascending=False)
        b = g.p_med.rank(ascending=False)
        churn.append({"cat": cat, "year": year,
                      "spearman": a.corr(b, method="spearman"),
                      "top10_overlap": len(set(g.oa_id[a <= 10]) & set(g.oa_id[b <= 10])) / 10,
                      "n": len(g)})
    CH = pd.DataFrame(churn)
    CH.to_csv(OUT / "reputation_counterfactual.csv", index=False)
    print(f"\nreputation counterfactual: rank corr {CH.spearman.mean():.3f}, "
          f"top-10 overlap {CH.top10_overlap.mean():.3f}")

    # ---- 5. decomposition by feature block -------------------------------
    from sklearn.metrics import roc_auc_score
    dec = []
    for lab_, cols in [("merit", MERIT), ("prizes", PRIZE), ("reputation", REP),
                       ("merit+prizes", MERIT + PRIZE), ("all", FEATS)]:
        b = lgb.train(params, lgb.Dataset(tr[cols], label=tr.y_nobel), 300)
        te["s"] = b.predict(te[cols])
        aucs = [roc_auc_score(g.y_nobel, g.s) for _, g in te.groupby(["cat", "year"])
                if g.y_nobel.nunique() > 1]
        dec.append({"spec": lab_, "auc": float(np.mean(aucs))})
    D = pd.DataFrame(dec)
    D.to_csv(OUT / "decomposition.csv", index=False)
    print(D.to_string(index=False))

    # ---- 6. forecast 2027-2031 ------------------------------------------
    full = lgb.train(params, lgb.Dataset(d[FEATS], label=d.y_nobel), 400)
    Lf = pd.read_csv(DATA / "roster_lifespan.csv")
    life = (M.merge(Lf, on="qid", how="left").dropna(subset=["oa_id"])
            .drop_duplicates("oa_id").set_index("oa_id"))
    last = df[df.year == 2026].copy()
    n0 = len(last)
    last["birth_year"] = last.oa_id.map(life.birth_year)
    last["death_year"] = last.oa_id.map(life.death_year)
    last = last[(last.death_year.isna()) | (last.death_year >= 2027)]
    last = last[(last.birth_year.isna()) | (last.birth_year.between(1930, 1988))]
    last = last[(last.works_5y >= 3) & (last.since_prize <= 12)]
    print(f"\nforecast risk set: {len(last):,} person-category rows from {n0:,}")
    mu, sd = df[FEATS].mean(), df[FEATS].std().replace(0, 1)
    for c in FEATS:
        last[c] = (last[c] - mu[c]) / sd[c]
    from sklearn.linear_model import LogisticRegression
    Ph = pd.read_parquet(OUT / "pred_hazard.parquet").dropna(subset=["p_lgbm"])
    lg = lambda v: np.log(np.clip(v, 1e-7, 1 - 1e-7) / (1 - np.clip(v, 1e-7, 1 - 1e-7)))
    platt = LogisticRegression().fit(lg(Ph.p_lgbm.values).reshape(-1, 1), Ph.y_nobel.values)
    last["p1"] = platt.predict_proba(lg(full.predict(last[FEATS])).reshape(-1, 1))[:, 1]
    name = dict(zip(M.oa_id, M.name))
    fc = last.groupby(["cat", "oa_id"]).agg(p1=("p1", "max"), n_prizes=("n_prizes", "max"),
                                            best_tier=("best_tier", "max"),
                                            birth_year=("birth_year", "first")).reset_index()
    fc["p5"] = 1 - (1 - fc.p1) ** 5
    fc["name"] = fc.oa_id.map(name)
    fc = fc.dropna(subset=["name"])
    fc.sort_values("p5", ascending=False).to_csv(OUT / "forecast.csv", index=False)
    print("\ntop of the 2027-2031 forecast:")
    print(fc.sort_values("p5", ascending=False).head(20)[
        ["name", "cat", "p5", "birth_year", "n_prizes"]].to_string(index=False))

    S = json.load(open(OUT / "summary.json")) if (OUT / "summary.json").exists() else {}
    S.update({"n_people": int(df.oa_id.nunique()), "n_rows": int(len(df)),
              "events": int(df.y_nobel.sum())})
    json.dump(S, open(OUT / "summary.json", "w"))


if __name__ == "__main__":
    main()
