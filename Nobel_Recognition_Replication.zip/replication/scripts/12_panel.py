#!/usr/bin/env python3
"""Stage 12 - person-year panel over the prize roster.

Every covariate is a function of information observable on 1 January of the
reference year: cumulative output and citations up to the previous year, recent
momentum, career age, the prizes already held, and the prior laureate production of
the author's institution, country and academic ancestry. The outcome is a Nobel in
that year; a person leaves the risk set in the year of the award.
"""

from __future__ import annotations

import json
import re
import unicodedata
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
CACHE = ROOT / "cache" / "oax"

Y0, Y1 = 1940, 2026
HORIZON = 60                      # years of risk per person
CAT_FIELD = {"Physics": {"31"}, "Chemistry": {"16"},
             "Medicine": {"27", "13", "24", "28", "30"}, "Economics": {"20"}}
COUNTRY = {"USA": "US", "United Kingdom": "GB", "Germany": "DE", "France": "FR",
           "Switzerland": "CH", "Japan": "JP", "Sweden": "SE", "Canada": "CA",
           "the Netherlands": "NL", "Netherlands": "NL", "Denmark": "DK",
           "USSR": "RU", "Russia": "RU", "Austria": "AT", "Italy": "IT",
           "Israel": "IL", "Norway": "NO", "Belgium": "BE", "Australia": "AU",
           "Argentina": "AR", "Hungary": "HU", "Czechoslovakia": "CZ",
           "Czech Republic": "CZ", "Finland": "FI", "Ireland": "IE", "India": "IN",
           "Spain": "ES", "China": "CN", "Taiwan": "TW", "Brazil": "BR",
           "South Africa": "ZA", "Poland": "PL", "Greece": "GR", "Mexico": "MX",
           "South Korea": "KR", "New Zealand": "NZ", "Portugal": "PT",
           "Turkey": "TR", "Singapore": "SG", "Iran": "IR", "Egypt": "EG"}
NOBEL_TO_CAT = {"Physics": "Physics", "Chemistry": "Chemistry",
                "Physiology or Medicine": "Medicine", "Economic Sciences": "Economics"}


def norm_inst(s: str) -> str:
    s = unicodedata.normalize("NFKD", str(s or ""))
    s = "".join(c for c in s if not unicodedata.combining(c)).lower()
    s = re.sub(r"\b(university|universite|universitat|universidad|college|institute|"
               r"institut|school|of|the|and|for|national|research|center|centre|"
               r"academy|sciences)\b", " ", s)
    return re.sub(r"[^a-z]", "", s)


def load_authors(keep: set[str]) -> list[dict]:
    out = []
    with (CACHE / "authors.jsonl").open() as fh:
        for line in fh:
            try:
                r = json.loads(line)
            except Exception:  # noqa: BLE001
                continue
            if r.get("id") in keep:
                out.append(r)
    return out


def category_of(rec: dict) -> list[str]:
    """Fields a person is at risk in: every Nobel category carrying at least a
    quarter of the mass of the dominant one, so interdisciplinary profiles compete
    in both of their communities."""
    counts: dict[str, int] = {}
    for t in rec.get("topics", []):
        f = t.get("field")
        if f:
            counts[f] = counts.get(f, 0) + (t.get("count") or 0)
    if not counts:
        return []
    score = {c: sum(v for f, v in counts.items() if f in fs) for c, fs in CAT_FIELD.items()}
    best = max(score.values())
    if best <= 0:
        return []
    return [c for c, v in score.items() if v >= 0.25 * best]


def pct_rank(x: np.ndarray) -> np.ndarray:
    """within-cohort percentile of a feature, computed on the risk set itself."""
    order = np.argsort(np.argsort(x))
    return order / max(len(x) - 1, 1)


def build(recs: list[dict], meta: dict[str, dict]) -> pd.DataFrame:
    rows = []
    for r in recs:
        cats = category_of(r)
        if not cats:
            continue
        cy = {int(d["year"]): (d.get("works_count") or 0, d.get("cited_by_count") or 0)
              for d in r.get("counts_by_year", []) if d.get("year")}
        if not cy:
            continue
        years = np.arange(Y0, Y1 + 1)
        works = np.array([cy.get(y, (0, 0))[0] for y in years], dtype=np.float32)
        cites = np.array([cy.get(y, (0, 0))[1] for y in years], dtype=np.float32)
        first = next((y for y in years if cy.get(y, (0, 0))[0] > 0), None)
        if first is None:
            continue
        cw, cc = np.cumsum(works), np.cumsum(cites)
        cw_prev = np.concatenate([[0], cw[:-1]])
        cc_prev = np.concatenate([[0], cc[:-1]])
        w5 = np.array([works[max(0, i - 4):i + 1].sum() for i in range(len(years))])
        c5 = np.array([cites[max(0, i - 4):i + 1].sum() for i in range(len(years))])
        c5p = np.array([cites[max(0, i - 9):max(0, i - 4)].sum() for i in range(len(years))])
        w3 = np.array([works[max(0, i - 2):i + 1].sum() for i in range(len(years))])

        aff = r.get("affiliations") or []
        inst_by_year: dict[int, str] = {}
        ctry_by_year: dict[int, str] = {}
        for a in aff:
            for y in a.get("years") or []:
                inst_by_year[int(y)] = a.get("name")
                ctry_by_year[int(y)] = a.get("country")
        cur_inst = aff[0].get("name") if aff else None
        cur_ctry = aff[0].get("country") if aff else None

        for i, y in enumerate(years):
            if y < first:
                continue
            cur_inst = inst_by_year.get(y, cur_inst)
            cur_ctry = ctry_by_year.get(y, cur_ctry)
            mx = float(np.max(cites[:i + 1])) if i else 0.0
            for cat in cats:
              rows.append((
                r["id"], cat, int(y),
                float(cw_prev[i]), float(cc_prev[i]), float(w5[i]), float(c5[i]),
                float(c5p[i]), float(y - first), float(w3[i]), mx,
                float(mx / cc_prev[i]) if cc_prev[i] > 0 else 0.0,
                float(c5[i] / max(c5p[i], 1.0)),
                norm_inst(cur_inst), cur_ctry,
            ))
    cols = ["oa_id", "cat", "year", "cum_works", "cum_cites", "works_5y", "cites_5y",
            "cites_prev5", "career_age", "works_3y", "peak_cites", "peak_share",
            "momentum", "inst", "country"]
    return pd.DataFrame(rows, columns=cols)


def main() -> None:
    M = pd.read_csv(DATA / "roster_match.csv")
    M = M[M.oa_id.notna()]
    keep = set(M.oa_id.astype(str))
    meta = {o: m for o, m in zip(M.oa_id.astype(str), M.name)}
    recs = load_authors(keep)
    print(f"roster matched {len(keep):,}  hydrated records {len(recs):,}")
    df = build(recs, meta)
    print(f"person-years {len(df):,}  people {df.oa_id.nunique():,}")
    print(df.cat.value_counts().to_string())

    # ---- prize history -------------------------------------------------
    R = pd.read_csv(DATA / "roster.csv").dropna(subset=["year"])
    R = R.merge(M[["qid", "oa_id"]], on="qid", how="inner")
    R["award_q"] = R.award_q.astype(str)
    L4 = pd.read_csv(DATA / "laureates.csv")
    L4 = L4[L4.category.isin(NOBEL_TO_CAT)].copy()
    L4["cat"] = L4.category.map(NOBEL_TO_CAT)
    L4["qid"] = L4.wikidata.str.rsplit("/", n=1).str[-1]
    nobel_q = {"Physics": {"Q38104"}, "Chemistry": {"Q44585"},
               "Medicine": {"Q80061"}, "Economics": {"Q47170"}}
    laureate_q = set(L4.qid)

    # prestige of each award = share of its recipients who hold a Nobel in the field
    aw = R.groupby("award_q").oa_id.nunique().rename("n_rec")
    hit = R[R.award_q.isin(nobel_q["Physics"] | nobel_q["Chemistry"] |
                           nobel_q["Medicine"] | nobel_q["Economics"])].groupby("award_q").oa_id.nunique()
    conv = (hit / aw).fillna(0.0).sort_values(ascending=False)
    tier = pd.cut(conv.rank(pct=True), [0, .5, .8, .93, .98, 1.0], labels=[1, 2, 3, 4, 5])
    tier = tier.astype(float).fillna(1.0)
    pri = R[R.award_q.isin(conv.index)].groupby(["oa_id", "year"]).agg(
        n_now=("award_q", "nunique"), best=("award_q", lambda s: tier[s].max())).reset_index()

    df["n_prizes"] = 0.0
    df["best_tier"] = 0.0
    df["years_since_prize"] = 99.0
    idx = {(o, y): (int(n), float(b)) for o, y, n, b in
           zip(pri.oa_id, pri.year, pri.n_now, pri.best)}
    pers_awards = pri.groupby("oa_id").year.apply(lambda s: sorted(s)).to_dict()
    n_prizes, best_tier, since = [], [], []
    for o, y in zip(df.oa_id, df.year):
        hist = pers_awards.get(o, [])
        past = [v for v in hist if v < y]
        n_prizes.append(float(len(past)))
        best_tier.append(max([idx[(o, v)][1] for v in past], default=0.0))
        since.append(float(y - max(past)) if past else 99.0)
    df["n_prizes"], df["best_tier"], df["years_since_prize"] = n_prizes, best_tier, since

    # ---- institutional / national laureate capital ----------------------
    L4["inst_n"] = L4.affiliation.map(norm_inst)
    inst_hist = {}
    for cat, g in L4.dropna(subset=["year"]).groupby("cat"):
        for nm, gg in g.groupby("inst_n"):
            if not nm:
                continue
            yrs = sorted(gg.year.tolist())
            for y in range(Y0, Y1 + 1):
                inst_hist[(cat, nm, y)] = sum(1 for v in yrs if v < y)
    L4["aff_country"] = L4.aff_country.map(lambda v: COUNTRY.get(v, v))
    ctry_hist = {}
    for cat, g in L4.dropna(subset=["year"]).groupby("cat"):
        for nm, gg in g.groupby("aff_country"):
            if not isinstance(nm, str) or not nm:
                continue
            yrs = sorted(gg.year.tolist())
            for y in range(Y0, Y1 + 1):
                ctry_hist[(cat, nm, y)] = sum(1 for v in yrs if v < y)
    df["inst_laureates"] = [float(inst_hist.get((c, i, y), 0))
                            for c, i, y in zip(df.cat, df.inst, df.year)]
    df["ctry_laureates"] = [float(ctry_hist.get((c, k, y), 0)) if isinstance(k, str) else 0.0
                            for c, k, y in zip(df.cat, df.country, df.year)]

    # ---- academic ancestry ---------------------------------------------
    adv_path = DATA / "roster_advisors.csv"
    df["laureate_advisor"] = 0.0
    if adv_path.exists():
        A = pd.read_csv(adv_path)
        if {"qid", "advisor"}.issubset(A.columns):
            A["advisor"] = A.advisor.str.rsplit("/", n=1).str[-1]
            anc = A.groupby("qid").advisor.apply(lambda s: any(q in laureate_q for q in s))
            anc = anc.reindex(M.qid).fillna(False)
            mp = dict(zip(M.qid, M.oa_id))
            hit_ids = {mp[q] for q, v in anc.items() if v and q in mp}
            df["laureate_advisor"] = df.oa_id.isin(hit_ids).astype(float)

    # ---- outcome --------------------------------------------------------
    won = L4.drop_duplicates("laureate_id").merge(M[["qid", "oa_id"]], on="qid", how="inner")
    won = won.groupby(["oa_id", "cat"]).year.min().reset_index().rename(columns={"year": "won_year"})
    df = df.merge(won, on=["oa_id", "cat"], how="left")
    person_won = won.groupby("oa_id").won_year.min()
    df["person_won"] = df.oa_id.map(person_won)
    df = df[df.person_won.isna() | (df.year <= df.person_won)]
    # a committee only considers scientists who are still publishing
    df = df[(df.works_5y > 0) | (df.won_year.notna())]
    df = df[df.career_age <= HORIZON]
    df["y_nobel"] = (df.won_year == df.year).astype("int8")
    df.to_parquet(DATA / "panel.parquet", index=False)
    print(f"\npanel {len(df):,} person-years  people {df.oa_id.nunique():,}  "
          f"events {int(df.y_nobel.sum())}")
    print(df.groupby("cat").agg(n=("y_nobel", "size"), ev=("y_nobel", "sum"),
                                ppl=("oa_id", "nunique")).to_string())


if __name__ == "__main__":
    main()
