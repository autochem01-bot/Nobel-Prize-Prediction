#!/usr/bin/env python3
"""Stage 8 - resolve every laureate to an OpenAlex author record at zero API cost.

ORCIDs are looked up directly. Otherwise we take DOIs for the laureate's papers from
Crossref, fetch a few of the works from OpenAlex (single-entity, free) and read the
author id off the authorship whose name matches. The modal id across papers wins,
which is robust to the odd homonym. Results are appended to a JSONL file so the
stage is fully resumable.
"""

from __future__ import annotations

import json
import re
import threading
import time
import unicodedata
import urllib.parse
import urllib.request
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
CACHE = ROOT / "cache" / "works"
CACHE.mkdir(parents=True, exist_ok=True)
OUT = DATA / "laureate_match_raw.jsonl"
UA = {"User-Agent": "nobel-scientometrics/1.0 (mailto:researcher@example.org)"}
LOCK = threading.Lock()


def norm(s: str) -> str:
    s = unicodedata.normalize("NFKD", str(s))
    s = "".join(c for c in s if not unicodedata.combining(c)).lower()
    s = re.sub(r"[^a-z\s]", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def get(url: str, tries: int = 3):
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers=UA)
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read())
        except Exception:  # noqa: BLE001
            time.sleep(1.0 * (i + 1))
    return None


def crossref_candidates(name: str, family: str, given: str, rows: int = 25) -> list[str]:
    q = urllib.parse.urlencode({"query.author": name, "rows": rows,
                                "select": "DOI,author,title", "mailto": "researcher@example.org"})
    d = get("https://api.crossref.org/works?" + q)
    if not d:
        return []
    out = []
    for it in d["message"]["items"]:
        auths = it.get("author") or []
        for k, a in enumerate(auths):
            if norm(a.get("family", "")) != family:
                continue
            g = norm(a.get("given", ""))
            if g and given and g[0] != given[0]:
                continue
            # prefer works where the target carries the paper or is one of few authors
            rank = 0 if len(auths) <= 4 else 1
            if k == 0:
                rank -= 0.5
            out.append((rank, it["DOI"]))
            break
    out.sort()
    return [d for _, d in out]


def work_authors(doi: str) -> list[tuple[str, str]]:
    path = CACHE / (re.sub(r"[^A-Za-z0-9]", "_", doi) + ".json")
    if path.exists():
        try:
            d = json.loads(path.read_text())
        except Exception:  # noqa: BLE001
            return []
    else:
        d = get("https://api.openalex.org/works/doi:" + urllib.parse.quote(doi))
        if not d:
            return []
        path.write_text(json.dumps(d))
    rows = []
    for a in d.get("authorships") or []:
        au = a.get("author") or {}
        aid = au.get("id")
        if not aid:
            continue
        rows.append((aid.rsplit("/", 1)[-1], au.get("display_name") or ""))
    return rows


def resolve(row) -> dict:
    lid, name, full = row.laureate_id, row.name, row.full_name
    full = full if isinstance(full, str) and full.strip() else name
    target = norm(full).split() or norm(name).split()
    fam, giv = target[-1], target[0][:1]

    orc = getattr(row, "orcid", None)
    if isinstance(orc, str) and orc and orc != "nan":
        d = get("https://api.openalex.org/authors/orcid:" + orc.strip())
        if d and d.get("id"):
            return {"laureate_id": lid, "oa_id": d["id"].rsplit("/", 1)[-1], "how": "orcid"}

    votes: Counter = Counter()
    for doi in crossref_candidates(name, fam, giv)[:5]:
        for aid, disp in work_authors(doi):
            n = norm(disp).split()
            if not n:
                continue
            if n[-1] == fam and n[0][0] == giv:
                votes[aid] += 1
    if votes:
        aid, k = votes.most_common(1)[0]
        return {"laureate_id": lid, "oa_id": aid, "how": "doi", "n_votes": k}
    return {"laureate_id": lid, "oa_id": None, "how": "none"}


def main() -> None:
    L = pd.read_csv(DATA / "laureates.csv")
    L = L[L.category.isin(["Physics", "Chemistry", "Physiology or Medicine", "Economic Sciences"])]
    L = L.drop_duplicates("laureate_id")
    done = set()
    if OUT.exists():
        with OUT.open() as fh:
            for line in fh:
                try:
                    r = json.loads(line)
                    done.add(r["laureate_id"])
                except Exception:  # noqa: BLE001
                    pass
    todo = L[~L.laureate_id.isin(done)]
    print(f"laureates {len(L)}  done {len(done)}  todo {len(todo)}", flush=True)

    t0 = time.time()
    with OUT.open("a") as fh, ThreadPoolExecutor(max_workers=10) as pool:
        futs = [pool.submit(resolve, r) for r in todo.itertuples()]
        for n, f in enumerate(as_completed(futs), 1):
            try:
                rec = f.result()
            except Exception as exc:  # noqa: BLE001
                print("  fail", exc, flush=True)
                continue
            with LOCK:
                fh.write(json.dumps(rec) + "\n")
            if n % 25 == 0:
                fh.flush()
                el = time.time() - t0
                print(f"  {n}/{len(todo)}  {n/el:.2f}/s  eta {(len(todo)-n)/(n/el)/60:.0f} min",
                      flush=True)
    fh_all = pd.read_json(OUT, lines=True)
    M = fh_all.merge(L[["laureate_id", "name", "category", "year"]], on="laureate_id")
    M.to_csv(DATA / "laureate_match.csv", index=False)
    print(f"resolved {M.oa_id.notna().sum()} / {len(M)}")
    print(M.groupby(["category", "how"]).size().to_string())


if __name__ == "__main__":
    main()
