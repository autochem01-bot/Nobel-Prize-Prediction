#!/usr/bin/env python3
"""Stage 5 - build the identifier list for the candidate universe.

Two free routes into OpenAlex: an explicit OpenAlex ID from Wikidata (P10283), or an
ORCID that OpenAlex resolves server-side. We collect both across the scientific
occupations that feed the four Nobel categories.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wd import sparql  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
P = ("PREFIX wd: <http://www.wikidata.org/entity/>\n"
     "PREFIX wdt: <http://www.wikidata.org/prop/direct/>\n")

OCC = {
    "physicist": "Q169470",
    "chemist": "Q593644",
    "economist": "Q188094",
    "physician": "Q39631",
    "biologist": "Q864503",
    "biochemist": "Q2919046",
    "geneticist": "Q3126128",
    "neuroscientist": "Q14565331",
    "scientist": "Q901",
    "researcher": "Q1650915",
}


def careful(query: str, tries: int = 3) -> list[dict]:
    for i in range(tries):
        try:
            return sparql(query)
        except Exception as exc:  # noqa: BLE001
            print(f"    fail ({exc}); retry {i+1}")
    return []


def main() -> None:
    frames = []

    print("openalex ids from Wikidata")
    rows = []
    for off in range(0, 60000, 15000):
        ch = careful(P + f"""SELECT ?p ?oax WHERE {{ ?p wdt:P10283 ?oax .
            ?p wdt:P31 wd:Q5 . }} ORDER BY ?p LIMIT 15000 OFFSET {off}""")
        rows.extend(ch)
        print(f"  {off}: {len(ch)}")
        if len(ch) < 15000:
            break
    if rows:
        d = pd.DataFrame(rows)
        d["qid"] = d.p.str.rsplit("/", n=1).str[-1]
        d["key"] = d.oax.str.rsplit("/", n=1).str[-1].map(lambda x: "A:" + x)
        frames.append(d[["qid", "key"]])

    print("orcids by occupation")
    for name, qid in OCC.items():
        rows = careful(P + f"""SELECT ?p ?o WHERE {{ ?p wdt:P106 wd:{qid} ; wdt:P496 ?o . }}
                               LIMIT 25000""")
        print(f"  {name}: {len(rows)}")
        if not rows:
            continue
        d = pd.DataFrame(rows)
        d["qid"] = d.p.str.rsplit("/", n=1).str[-1]
        d["key"] = d.o.str.rsplit("/", n=1).str[-1].map(lambda x: "O:" + x)
        d["occupation"] = name
        frames.append(d[["qid", "key"]])

    allids = pd.concat(frames).drop_duplicates("qid")
    # prefer the explicit OpenAlex id when a person has both
    order = allids.key.str[0].map({"A": 0, "O": 1})
    allids = allids.assign(_o=order).sort_values(["qid", "_o"]).drop_duplicates("qid")
    allids = allids.drop(columns="_o")
    allids.to_csv(DATA / "candidate_ids.csv", index=False)
    print(f"unique people: {len(allids)}  (A: {(allids.key.str[0]=='A').sum()}, "
          f"O: {(allids.key.str[0]=='O').sum()})")


if __name__ == "__main__":
    main()
