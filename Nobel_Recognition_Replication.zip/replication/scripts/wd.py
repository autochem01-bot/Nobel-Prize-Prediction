#!/usr/bin/env python3
"""Throttled, cached Wikidata SPARQL client."""

from __future__ import annotations

import hashlib
import json
import time
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CACHE = ROOT / "cache" / "wd"
CACHE.mkdir(parents=True, exist_ok=True)
ENDPOINT = "https://query.wikidata.org/sparql"
UA = "nobel-scientometrics/1.0 (academic research; contact: researcher@example.org)"

_last = [0.0]


def _throttle(gap: float = 1.1) -> None:
    dt = time.time() - _last[0]
    if dt < gap:
        time.sleep(gap - dt)
    _last[0] = time.time()


def sparql(query: str, retries: int = 6, use_cache: bool = True) -> list[dict]:
    key = hashlib.sha256(query.encode()).hexdigest()[:24]
    path = CACHE / f"{key}.json"
    if use_cache and path.exists():
        return json.loads(path.read_text())

    url = ENDPOINT + "?" + urllib.parse.urlencode({"query": query, "format": "json"})
    for attempt in range(retries):
        _throttle()
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA,
                                                       "Accept": "application/sparql-results+json"})
            with urllib.request.urlopen(req, timeout=120) as r:
                payload = json.loads(r.read())
            rows = [
                {k: v.get("value") for k, v in b.items()}
                for b in payload["results"]["bindings"]
            ]
            path.write_text(json.dumps(rows))
            return rows
        except Exception as exc:  # noqa: BLE001
            wait = min(60, 2 ** attempt * 3)
            print(f"    wd retry {attempt+1}/{retries} ({exc}) sleep {wait}s")
            time.sleep(wait)
    raise RuntimeError("Wikidata query failed")


def values(items: list[str]) -> str:
    return " ".join(f"wd:{i}" for i in items)
