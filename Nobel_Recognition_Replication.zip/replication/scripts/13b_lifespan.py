#!/usr/bin/env python3
"""Stage 13b - birth and death years for roster members (Wikidata P569/P570)."""

from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wd import sparql  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
P = ("PREFIX wd: <http://www.wikidata.org/entity/>\n"
     "PREFIX wdt: <http://www.wikidata.org/prop/direct/>\n")


def main() -> None:
    qids = sorted(set(pd.read_csv(DATA / "roster_meta.csv").qid))
    rows = []
    for i in range(0, len(qids), 400):
        chunk = qids[i:i + 400]
        vals = " ".join("wd:" + q for q in chunk)
        got = []
        for _ in range(3):
            try:
                got = sparql(P + f"""SELECT ?p ?b ?d WHERE {{
                    VALUES ?p {{ {vals} }}
                    OPTIONAL {{ ?p wdt:P569 ?b }}
                    OPTIONAL {{ ?p wdt:P570 ?d }} }}""")
                break
            except Exception as exc:  # noqa: BLE001
                print("  retry", exc)
        for r in got:
            rows.append({"qid": r["p"].rsplit("/", 1)[-1],
                         "birth": r.get("b"), "death": r.get("d")})
        print(f"  {i + len(chunk)}/{len(qids)}", flush=True)
    L = pd.DataFrame(rows).drop_duplicates("qid")
    L["birth_year"] = pd.to_datetime(L.birth, errors="coerce", utc=True).dt.year
    L["death_year"] = pd.to_datetime(L.death, errors="coerce", utc=True).dt.year
    L[["qid", "birth_year", "death_year"]].to_csv(DATA / "roster_lifespan.csv", index=False)
    print(f"people {len(L)}  birth known {L.birth_year.notna().sum()}  "
          f"death known {L.death_year.notna().sum()}")


if __name__ == "__main__":
    main()
