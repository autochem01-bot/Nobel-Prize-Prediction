#!/usr/bin/env python3
"""Stage 4 - assemble a large list of candidate scientists with OpenAlex IDs.

Wikidata stores an OpenAlex ID (P10283) for a large number of researchers, and the
OpenAlex single-entity endpoint is free, so this gives us a big, precise pool at no
API cost. We keep every human with an OpenAlex ID plus whatever profile fields
Wikidata can supply cheaply.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wd import sparql  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"

PREFIX = """
PREFIX wd: <http://www.wikidata.org/entity/>
PREFIX wdt: <http://www.wikidata.org/prop/direct/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
"""


def main() -> None:
    rows: list[dict] = []
    page = 20000
    for off in range(0, 400000, page):
        q = PREFIX + f"""
SELECT ?p ?oax WHERE {{
  ?p wdt:P10283 ?oax .
  ?p wdt:P31 wd:Q5 .
}} ORDER BY ?p LIMIT {page} OFFSET {off}"""
        chunk = sparql(q)
        print(f"  offset {off}: {len(chunk)}")
        rows.extend(chunk)
        if len(chunk) < page:
            break
    df = pd.DataFrame(rows).drop_duplicates("p")
    df["qid"] = df.p.str.rsplit("/", n=1).str[-1]
    df["openalex"] = df.oax.str.rsplit("/", n=1).str[-1]
    df = df[["qid", "openalex"]]
    df.to_csv(DATA / "scientist_ids.csv", index=False)
    print(f"humans with an OpenAlex ID: {len(df)}")


if __name__ == "__main__":
    main()
